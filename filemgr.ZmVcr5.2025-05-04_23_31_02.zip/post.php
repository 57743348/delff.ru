<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Обновление активности пользователя
$current_time = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("UPDATE users SET last_activity = ? WHERE user_id = ?");
$stmt->execute([$current_time, $_SESSION['user_id']]);

// Получение количества онлайн пользователей
$online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
$online_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE last_activity > ?");
    $stmt->execute([$online_threshold]);
    $result = $stmt->fetch();
    $online_count = $result['count'];
} catch (PDOException $e) {
    // Игнорируем ошибку
}

// Получение данных пользователя
$user = [];
try {
    $stmt = $pdo->prepare("SELECT username, avatar, bio, display_name, last_activity, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
}

function checkCommentSpam($pdo) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_id = $_SESSION['user_id'];
    
    // Проверяем, заблокирован ли уже IP
    $stmt = $pdo->prepare("SELECT ban_until FROM comment_bans WHERE ip = ?");
    $stmt->execute([$ip]);
    $ban = $stmt->fetch();
    
    if ($ban && strtotime($ban['ban_until']) > time()) {
        // Пользователь заблокирован
        $remaining = strtotime($ban['ban_until']) - time();
        $_SESSION['error'] = "Вы заблокированы за спам. Попробуйте снова через ".ceil($remaining/60)." минут.";
        header("Location: main.php");
        exit();
    }
    
    // Проверяем количество комментариев за последнюю минуту
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM comments WHERE user_id = ? AND created_at > NOW() - INTERVAL 1 MINUTE");
    $stmt->execute([$user_id]);
    $count = $stmt->fetch()['count'];
    
    if ($count >= 5) {
        // Удаляем все комментарии пользователя
        try {
            $stmt = $pdo->prepare("DELETE FROM comments WHERE user_id = ?");
            $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            error_log("Error deleting spam comments: " . $e->getMessage());
        }
        
        // Блокируем пользователя
        $banDuration = 5 * 60; // 5 минут в секундах
        $banUntil = date('Y-m-d H:i:s', time() + $banDuration);
        
        // Проверяем, есть ли уже запись об этом IP
        $stmt = $pdo->prepare("SELECT id FROM comment_bans WHERE ip = ?");
        $stmt->execute([$ip]);
        $existingBan = $stmt->fetch();
        
        if ($existingBan) {
            // Увеличиваем время бана в 2 раза за повторные нарушения
            $stmt = $pdo->prepare("UPDATE comment_bans SET ban_until = ?, ban_count = ban_count + 1 WHERE ip = ?");
            $stmt->execute([$banUntil, $ip]);
        } else {
            // Первое нарушение
            $stmt = $pdo->prepare("INSERT INTO comment_bans (ip, ban_until, ban_count) VALUES (?, ?, 1)");
            $stmt->execute([$ip, $banUntil]);
        }
        
        $_SESSION['error'] = "Вы отправляете слишком много комментариев. Все ваши комментарии удалены, и вы заблокированы на 5 минут.";
        header("Location: post.php?id=".$_GET['id']);
        exit();
    }
}

// Получаем данные поста
$post = [];
$is_liked = false;
$likes_count = 0;
$comments_count = 0;
if (isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("
            SELECT p.post_id, p.title, p.content, p.created_at, u.user_id, u.username, u.avatar, u.display_name, u.role, u.last_activity
            FROM posts p
            JOIN users u ON p.user_id = u.user_id
            WHERE p.post_id = ?
        ");
        $stmt->execute([$_GET['id']]);
        $post = $stmt->fetch();
        
        if (!$post) {
            $_SESSION['error'] = 'Пост не найден';
            header("Location: main.php");
            exit();
        }
        
        // Получаем информацию о лайках
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM likes WHERE post_id = ?");
        $stmt->execute([$post['post_id']]);
        $likes_count = $stmt->fetch()['count'];
        
        // Проверяем, лайкнул ли текущий пользователь
        $stmt = $pdo->prepare("SELECT 1 FROM likes WHERE post_id = ? AND user_id = ?");
        $stmt->execute([$post['post_id'], $_SESSION['user_id']]);
        $is_liked = (bool)$stmt->fetch();
        
        // Получаем количество комментариев
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM comments WHERE post_id = ?");
        $stmt->execute([$post['post_id']]);
        $comments_count = $stmt->fetch()['count'];
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Ошибка при получении поста';
        header("Location: main.php");
        exit();
    }
} else {
    $_SESSION['error'] = 'Не указан ID поста';
    header("Location: main.php");
    exit();
}

// В обработчике отправки комментария
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_text'])) {
    // Проверяем на спам перед добавлением комментария
    checkCommentSpam($pdo);
    
    $comment_text = trim($_POST['comment_text']);
    if (!empty($comment_text)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$post['post_id'], $_SESSION['user_id'], $comment_text]);
            $_SESSION['success'] = 'Комментарий добавлен';
            header("Location: post.php?id=" . $post['post_id']);
            exit();
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Ошибка при добавлении комментария';
            error_log("Error adding comment: " . $e->getMessage());
        }
    }
}

// Получаем комментарии к посту
$comments = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.comment_id, c.content, c.created_at, u.user_id, u.username, u.avatar, u.display_name, u.role, u.last_activity
        FROM comments c
        JOIN users u ON c.user_id = u.user_id
        WHERE c.post_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$post['post_id']]);
    $comments = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении комментариев';
}

function isUserOnline($last_activity) {
    $online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
    return $last_activity > $online_threshold;
}

function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    return $roles[$role] ?? 'user';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($post['title']) ?> | Interpol Organizations</title>
  <link rel="icon" href="/uploads/favicon.ico">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Oswald', sans-serif;
    }

    body {
        background-color: #1a1a1a;
        color: #ffffff;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .container {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        flex: 1;
    }
    
    .post-action.liked i {
        color: red;
    }
    
    .glow-hover {
        color: #fff;
        transition: text-shadow 0.3s ease;
        text-shadow: 0 0 8px white, 0 0 16px white;
    }

    /* Header */
    .header {
        background-color: #272727;
        height: 45px;
        display: flex;
        align-items: center;
        padding: 0 20px;
        border-bottom: 1px solid #3d3d3d;
        width: 100%;
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .logo-img {
        height: 30px;
    }

    .logo-text {
        font-size: 20px;
        font-weight: 400;
        color: #fff;
    }

    .nav {
        display: flex;
        margin-left: 30px;
    }

    .nav-item {
        color: #fff;
        text-decoration: none;
        padding: 0 15px;
        font-size: 16px;
        transition: color 0.3s;
        height: 45px;
        display: flex;
        align-items: center;
    }

    .nav-item:hover {
        color: #ccc;
        background-color: #3d3d3d;
    }

    .right-section {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 10px;
        position: relative;
    }

    .user-role {
        display: inline-block;
        font-size: 0.7rem;
        padding: 2px 5px;
        border-radius: 3px;
        margin-right: 5px;
        text-transform: uppercase;
        font-weight: bold;
    }

    /* Стили для ролей */
    .role-admin {
        background-color: #d32f2f;
        color: white;
        text-shadow: 0 0 5px rgba(255, 0, 0, 0.7);
    }

    .role-moderator {
        background-color: #7b1fa2;
        color: white;
        text-shadow: 0 0 5px rgba(180, 0, 255, 0.7);
    }

    .role-vip {
        background: linear-gradient(45deg, #ffc107, #ff9800);
        color: black;
        text-shadow: 0 0 5px rgba(255, 215, 0, 0.7);
    }

    .role-premium {
        background: linear-gradient(45deg, #4caf50, #8bc34a);
        color: white;
        text-shadow: 0 0 5px rgba(0, 255, 0, 0.7);
    }

    .role-helper {
        background-color: #0288d1;
        color: white;
        text-shadow: 0 0 5px rgba(0, 150, 255, 0.7);
    }

    .role-designer {
        background: linear-gradient(45deg, #e91e63, #9c27b0);
        color: white;
        text-shadow: 0 0 5px rgba(255, 0, 150, 0.7);
    }

    .role-developer {
        background-color: #607d8b;
        color: white;
        text-shadow: 0 0 5px rgba(100, 150, 200, 0.7);
    }

    .role-tester {
        background-color: #795548;
        color: white;
        text-shadow: 0 0 5px rgba(150, 100, 50, 0.7);
    }

    .role-writer {
        background: linear-gradient(45deg, #3f51b5, #2196f3);
        color: white;
        text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
    }

    .role-support {
        background: linear-gradient(45deg, #009688, #4caf50);
        color: white;
        text-shadow: 0 0 5px rgba(0, 255, 200, 0.7);
    }

    .role-guest {
        background-color: #9e9e9e;
        color: white;
        text-shadow: 0 0 5px rgba(200, 200, 200, 0.7);
    }

    .role-user {
        background-color: #1976d2;
        color: white;
        text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
    }

    .right-image {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid #555;
        cursor: pointer;
        transition: transform 0.3s;
    }

    .right-image:hover {
        transform: scale(1.1);
    }

    .dropdown-menu1 {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        background: rgba(0, 0, 0, 0.9);
        border: 1px solid #333;
        border-radius: 5px;
        padding: 10px 0;
        min-width: 150px;
        z-index: 100;
    }

    .dropdown-menu1 a {
        display: block;
        padding: 8px 15px;
        font-size: 14px;
        color: white;
        text-decoration: none;
        white-space: nowrap;
    }

    .dropdown-menu1 a:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    .right-section:hover .dropdown-menu1 {
        display: block;
    }

    /* Online counter */
    .online-counter {
        position: fixed;
        top: 60px;
        right: 20px;
        background-color: #272727;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 14px;
        transition: background-color 0.3s;
        z-index: 100;
    }

    .online-counter-update {
        background-color: #3d3d3d;
    }

    /* Main Content */
    .main-content {
        display: flex;
        min-height: calc(100vh - 45px);
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
    }

    /* Sidebar */
    .sidebar {
        width: 280px;
        background-color: rgba(39, 39, 39, 0.7);
        padding: 20px;
        border-right: 1px solid #3d3d3d;
    }

    .sidebar-title {
        color: #ccc;
        font-size: 18px;
        margin-bottom: 15px;
        padding-bottom: 5px;
        border-bottom: 1px solid #3d3d3d;
    }

    .sidebar-item {
        color: #fff;
        display: block;
        padding: 8px 10px;
        margin-bottom: 5px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.3s;
    }

    .sidebar-item:hover {
        background-color: #3d3d3d;
    }

    /* Стили для раскрывающихся кнопок */
    .dropdown-btn {
        background-color: rgba(39, 39, 39, 0);
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
        width: 100%;
        border: none;
        text-align: left;
        cursor: pointer;
        border-radius: 4px;
        margin-bottom: 5px;
        transition: all 0.3s;
    }

    .dropdown-btn:hover {
        background-color: #3d3d3d;
    }

    .dropdown-btn.active {
        background-color: #3d3d3d;
        border-radius: 4px 4px 0 0;
        margin-bottom: 0;
    }

    .dropdown-btn::after {
        content: "▼";
        font-size: 12px;
    }

    .dropdown-btn.active::after {
        content: "▲";
    }

    .dropdown-container {
        display: none;
        background-color: #1e1e1e;
        padding: 0;
        border-radius: 0 0 4px 4px;
        margin-bottom: 5px;
        overflow: hidden;
    }

    .dropdown-container a {
        color: #fff;
        padding: 8px 20px;
        text-decoration: none;
        display: block;
        transition: all 0.3s;
    }

    .dropdown-container a:hover {
        background-color: #333;
    }
    
    .create-post-btn {
        background-color: #fff;
        color: #000;
        display: block;
        width: 100%;
        padding: 10px;
        text-align: center;
        border-radius: 6px;
        font-size: 16px;
        margin-bottom: 20px;
        cursor: pointer;
        transition: background-color 0.3s;
        border: none;
    }

    .create-post-btn:hover {
        background-color: #e6e6e6;
    }

    /* Content Area */
    .content {
        flex: 1;
        padding: 20px;
        max-width: 900px;
    }

    /* Post detail */
    .post-detail {
        background-color: #272727;
        border-radius: 7px;
        padding: 20px;
        margin-bottom: 20px;
    }

    .post-header {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
    }

    .post-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: #3d3d3d;
        margin-right: 10px;
        position: relative;
        overflow: hidden;
    }

    .post-user {
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .post-date {
        color: #999;
        font-size: 14px;
        margin-left: auto;
    }

    .post-title {
        font-size: 24px;
        margin-bottom: 15px;
        color: #fff;
    }

    .post-content {
        line-height: 1.6;
        color: #eee;
        margin-bottom: 20px;
        word-wrap: break-word;
        white-space: pre-line;
    }

    .post-footer {
        display: flex;
        color: #ccc;
        font-size: 14px;
        margin-top: 20px;
    }

    .post-action {
        margin-right: 20px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 5px;
        transition: all 0.3s;
    }

    .post-action:hover {
        color: #fff;
    }

    .post-action i.liked {
        color: #f44336;
    }

    .post-actions {
        display: flex;
        gap: 10px;
        margin-top: 20px;
    }

    .btn {
        padding: 8px 15px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        font-size: 14px;
        transition: all 0.3s;
    }

    .back-btn {
        background-color: #3d3d3d;
        color: #fff;
    }

    .back-btn:hover {
        background-color: #4d4d4d;
    }

    .edit-btn {
        background-color: #1976d2;
        color: #fff;
    }

    .edit-btn:hover {
        background-color: #1565c0;
    }

    .delete-btn {
        background-color: #d32f2f;
        color: #fff;
    }

    .delete-btn:hover {
        background-color: #b71c1c;
    }

    /* Comments section */
    .comments-section {
        background-color: #272727;
        border-radius: 7px;
        padding: 20px;
        margin-bottom: 20px;
    }

    .comments-title {
        font-size: 20px;
        margin-bottom: 15px;
        color: #fff;
    }

    .comment-form {
        margin-bottom: 20px;
    }

    .comment-textarea {
        width: 100%;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #3d3d3d;
        background-color: #2d2d2d;
        color: #fff;
        min-height: 100px;
        margin-bottom: 10px;
        resize: vertical;
    }

    .comment-submit {
        background-color: #1976d2;
        color: #fff;
        padding: 8px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .comment-submit:hover {
        background-color: #1565c0;
    }

    .comment-list {
        margin-top: 20px;
    }

    .comment-item {
        background-color: #2d2d2d;
        border-radius: 4px;
        padding: 15px;
        margin-bottom: 15px;
    }

    .comment-header {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }

    .comment-avatar {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-right: 10px;
        position: relative;
    }

    .comment-author {
        font-weight: 500;
        margin-right: 10px;
    }

    .comment-date {
        color: #999;
        font-size: 12px;
        margin-left: auto;
    }

    .comment-content {
        line-height: 1.5;
        color: #eee;
        margin-bottom: 10px;
        word-wrap: break-word;
        white-space: pre-line;
    }

    .comment-actions {
        display: flex;
        justify-content: flex-end;
    }

    .comment-action {
        color: #999;
        font-size: 12px;
        cursor: pointer;
        transition: color 0.3s;
    }

    .comment-action:hover {
        color: #fff;
    }

    /* Messages */
    .message {
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
    }

    .error {
        background-color: #d32f2f;
        color: #fff;
    }

    .success {
        background-color: #388e3c;
        color: #fff;
    }

    /* Background image */
    .background-image {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.7);
        width: 100vw;
        height: 100vh;
        z-index: -1;
        overflow: hidden;
        min-width: 800px;
        min-height: 800px;
    }

    .background-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
        min-width: 800px;
        min-height: 800px;
    }

    @keyframes like {
        0% { transform: scale(1); }
        50% { transform: scale(1.3); }
        100% { transform: scale(1); }
    }

    .online-indicator {
        width: 8px;
        height: 8px;
        background-color: #4CAF50;
        border-radius: 50%;
        position: absolute;
        bottom: 0;
        right: 0;
        border: 1px solid #272727;
    }
  </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="dsdsd.png" alt="Interpol Logo" class="logo-img">
            <div class="logo-text">Interpol organizations</div>
        </div>
        <nav class="nav">
            <a href="main.php" class="nav-item">Главная</a>
            <a href="https://t.me/+qHVi5eFtG_A1YTk6" class="nav-item">О нас</a>
        </nav>
        
        <!-- Online counter -->
        <div class="online-counter" id="onlineCounter">
            Онлайн: <?= $online_count ?>
        </div>
        
        <div class="right-section">
            <a href="profile.php" style="color: white; text-decoration: none;">
                <span class="user-role role-<?= getRoleClass($user['role']) ?>">
                    <?= strtoupper($user['role']) ?>
                </span>
                <?= htmlspecialchars($user['display_name'] ?? 'Пользователь') ?>
            </a>
            <div style="position: relative;" data-user-id="<?= $_SESSION['user_id'] ?>">
                <img src="/uploads/<?= htmlspecialchars($user['avatar'] ?? '333.png') ?>" alt="Аватар" class="right-image">
                <span class="online-indicator"></span>
            </div>
            
            <!-- Dropdown menu -->
            <div class="dropdown-menu1">
                <a href="profile.php">Профиль</a>
                <a href="settings.php">Настройки</a>
                <a href="logout.php">Выйти</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
                <?php if ($user['role'] === 'admin' || $user['role'] === 'moderator' || $user['role'] === 'writer'): ?>
                    <button class="create-post-btn" onclick="window.location.href='addpost.php'">Создать пост</button>
                <?php endif; ?>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Категории</div>
                    <a href="main.php" class="sidebar-item">Главная</a>
                    
                    <!-- Кнопка Cheat с выпадающим списком -->
                    <button class="dropdown-btn">Cheat</button>
                    <div class="dropdown-container">
                        <a href="cs2.php" class="glow-hover">Counter-Strike 2</a>
                        <a href="roblox.php">Roblox</a>
                        <a href="dota2.php">Dota 2</a>
                        <a href="other.php">Остальное</a>
                        <a href="addrole.php">Заявки на роль</a>
                    </div>
                </div>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Обсуждение</div>
                    <a href="offers.php" class="sidebar-item">Предложения</a>
                </div>
            </aside>

            <!-- Content Area -->
            <main class="content">
                <!-- Post detail -->
                <div class="post-detail">
                   <!-- Post header (измененная часть) -->
<div class="post-header" onclick="window.location.href='profile_view.php?id=<?= $post['user_id'] ?>'" style="cursor: pointer;">
    <div class="post-avatar" data-user-id="<?= $post['user_id'] ?>">
        <img src="/uploads/<?= htmlspecialchars($post['avatar'] ?? '333.png') ?>" alt="Аватар" style="width:100%;height:100%;object-fit:cover;">
        <span class="online-indicator" style="display: <?= isUserOnline($post['last_activity']) ? 'block' : 'none' ?>;"></span>
    </div>
    <div class="post-user">
        <span class="user-role role-<?= getRoleClass($post['role']) ?>">
            <?= strtoupper($post['role']) ?>
        </span>
        <?= htmlspecialchars($post['display_name']) ?>
    </div>
    <div class="post-date">
        <i class="far fa-calendar-alt"></i> <?= date('d.m.Y H:i', strtotime($post['created_at'])) ?>
    </div>
</div>
                    
                    <h1 class="post-title"><?= htmlspecialchars($post['title']) ?></h1>
                    
                    <div class="post-content">
                        <?= nl2br(htmlspecialchars($post['content'])) ?>
                    </div>
                    
                    <div class="post-footer">
                        <div class="post-action <?= $is_liked ? 'liked' : '' ?>" onclick="toggleLike(event, <?= $post['post_id'] ?>)">
                            <i class="fas fa-heart"></i>
                            <span class="like-count"><?= $likes_count ?></span>
                        </div>
                        
                        <div class="post-action">
                            <i class="fas fa-comment"></i>
                            <span class="comment-count"><?= $comments_count ?></span>
                        </div>
                    </div>
                    
                    <div class="post-actions">
                        <button class="btn back-btn" onclick="window.history.back()">Назад</button>
                        <?php if ($user['role'] === 'admin'): ?>
                            <button class="btn edit-btn" onclick="location.href='edit_post.php?id=<?= $post['post_id'] ?>'">Изменить</button>
                            <button class="btn delete-btn" onclick="confirmDelete(<?= $post['post_id'] ?>)">Удалить</button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Comments section -->
                <div class="comments-section">
                    <h2 class="comments-title">Комментарии</h2>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="message error"><?= $_SESSION['error'] ?></div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="message success"><?= $_SESSION['success'] ?></div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <!-- Comment form -->
                    <form class="comment-form" method="POST">
                        <textarea name="comment_text" class="comment-textarea" placeholder="Напишите ваш комментарий..." required></textarea>
                        <button type="submit" class="comment-submit">Отправить</button>
                    </form>
                    
                    <!-- Comments list -->
                    <div class="comment-list">
                        <?php if (empty($comments)): ?>
                            <div class="comment-item">Пока нет комментариев. Будьте первым!</div>
                        <?php else: ?>
                            <?php foreach ($comments as $comment): ?>
                                <div class="comment-item">
                                  <div class="comment-header" onclick="window.location.href='profile_view.php?id=<?= $comment['user_id'] ?>'" style="cursor: pointer;">
    <div class="comment-avatar" data-user-id="<?= $comment['user_id'] ?>">
        <img src="/uploads/<?= htmlspecialchars($comment['avatar'] ?? '333.png') ?>" alt="Аватар" style="width:100%;height:100%;object-fit:cover;">
        <span class="online-indicator" style="display: <?= isUserOnline($comment['last_activity']) ? 'block' : 'none' ?>;"></span>
    </div>
    <div class="post-user">
        <span class="user-role role-<?= getRoleClass($comment['role']) ?>">
            <?= strtoupper($comment['role']) ?>
        </span>
        <?= htmlspecialchars($comment['display_name']) ?>
    </div>
    <div class="comment-date">
        <?= date('d.m.Y H:i', strtotime($comment['created_at'])) ?>
    </div>
</div>
                                    <div class="comment-content">
                                        <?= nl2br(htmlspecialchars($comment['content'])) ?>
                                    </div>
                                    <?php if ($user['role'] === 'admin' || $comment['user_id'] == $_SESSION['user_id']): ?>
                                        <div class="comment-actions">
                                            <span class="comment-action" onclick="confirmDeleteComment(<?= $comment['comment_id'] ?>)">Удалить</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Background image -->
    <div class="background-image">
        <img src="123333.png" alt="Фоновое изображение">
    </div>

    <script>
    // Функция для обновления онлайн статуса
    function updateOnlineStatus() {
        fetch('update_activity.php')
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                const onlineCounter = document.getElementById('onlineCounter');
                if (onlineCounter) {
                    onlineCounter.textContent = `Онлайн: ${data.online_count}`;
                    onlineCounter.classList.add('online-counter-update');
                    setTimeout(() => {
                        onlineCounter.classList.remove('online-counter-update');
                    }, 1000);
                }
                
                document.querySelectorAll('.online-indicator').forEach(indicator => {
                    const parentDiv = indicator.closest('[data-user-id]');
                    if (parentDiv) {
                        const userId = parseInt(parentDiv.getAttribute('data-user-id'));
                        if (data.online_users.includes(userId)) {
                            indicator.style.display = 'block';
                        } else {
                            indicator.style.display = 'none';
                        }
                    }
                });
            })
            .catch(error => console.error('Ошибка при обновлении статуса:', error));
    }

    // Функция для обработки лайков
    async function toggleLike(event, postId) {
        event.stopPropagation();
        
        const likeElement = event.currentTarget;
        const likeIcon = likeElement.querySelector('i');
        const likeCountElement = likeElement.querySelector('.like-count');
        let isLiked = likeElement.classList.contains('liked');
        
        try {
            const response = await fetch('toggle_like.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `post_id=${postId}&action=${isLiked ? 'unlike' : 'like'}`
            });
            
            if (!response.ok) throw new Error('Network error');
            
            const data = await response.json();
            
            if (data.success) {
                likeElement.classList.toggle('liked', data.is_liked);
                likeCountElement.textContent = data.likes_count;
                
                if (!isLiked) {
                    likeIcon.style.animation = 'like 0.5s';
                    setTimeout(() => {
                        likeIcon.style.animation = '';
                    }, 500);
                }
            } else {
                alert(data.message || 'Ошибка при обработке лайка');
            }
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при обработке лайка');
        }
    }

    // Функция для подтверждения удаления поста
    function confirmDelete(postId) {
        if (confirm('Вы уверены, что хотите удалить этот пост? Это действие нельзя отменить.')) {
            fetch('delete_post.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${postId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'main.php';
                } else {
                    alert(data.message || 'Ошибка при удалении поста');
                }
            })
            .catch(error => {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении поста');
            });
        }
    }

    // Функция для подтверждения удаления комментария
    function confirmDeleteComment(commentId) {
        if (confirm('Вы уверены, что хотите удалить этот комментарий?')) {
            fetch('delete_comment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${commentId}&post_id=<?= $post['post_id'] ?>`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Ошибка при удалении комментария');
                }
            })
            .catch(error => {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении комментария');
            });
        }
    }

    // Скрипт для раскрывающихся кнопок в боковой панели
    document.querySelectorAll(".dropdown-btn").forEach(btn => {
        btn.addEventListener("click", function(event) {
            event.stopPropagation();
            this.classList.toggle("active");
            const dropdownContent = this.nextElementSibling;
            dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
        });
    });

    // Закрытие выпадающих меню при клике вне их
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.dropdown-btn') && !event.target.closest('.dropdown-container')) {
            document.querySelectorAll('.dropdown-container').forEach(container => {
                container.style.display = 'none';
            });
            document.querySelectorAll('.dropdown-btn').forEach(btn => {
                btn.classList.remove('active');
            });
        }
    });

    // Initialize
    updateOnlineStatus();
    
    // Также обновляем статус при возвращении на страницу
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            updateOnlineStatus();
        }
    });

    // Обновляем онлайн статус каждые 30 секунд
    setInterval(updateOnlineStatus, 30000);

    // Обработка отправки формы комментария
    document.querySelector('.comment-form')?.addEventListener('submit', function(e) {
        const textarea = this.querySelector('textarea');
        if (textarea.value.trim().length === 0) {
            e.preventDefault();
            alert('Комментарий не может быть пустым');
        }
    });
</script>
</body>
</html>
