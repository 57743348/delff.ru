<?php
session_start();
require 'db_connect.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || !isset($_POST['user_id']) || !isset($_POST['role'])) {
    echo json_encode(['success' => false, 'error' => 'Недостаточно прав']);
    exit();
}

try {
    // Check if current user is admin
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if ($user['role'] !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Недостаточно прав']);
        exit();
    }
    
    // Update role
    $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE user_id = ?");
    $stmt->execute([$_POST['role'], $_POST['user_id']]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Ошибка базы данных']);
}
?>