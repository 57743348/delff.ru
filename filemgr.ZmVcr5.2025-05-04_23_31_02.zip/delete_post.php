<?php
session_start();

// Проверка авторизации и прав администратора
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Проверяем, является ли пользователь администратором
try {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user || $user['role'] !== 'admin') {
        $_SESSION['error'] = 'У вас нет прав для выполнения этого действия';
        header("Location: main.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при проверке прав доступа';
    header("Location: main.php");
    exit();
}

// Проверяем наличие ID поста
if (!isset($_GET['id'])) {
    $_SESSION['error'] = 'Не указан ID поста';
    header("Location: main.php");
    exit();
}

$post_id = $_GET['id'];

// Удаляем пост
try {
    $stmt = $pdo->prepare("DELETE FROM posts WHERE post_id = ?");
    $stmt->execute([$post_id]);
    
    if ($stmt->rowCount() > 0) {
        $_SESSION['success'] = 'Пост успешно удален';
    } else {
        $_SESSION['error'] = 'Пост не найден или уже удален';
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при удалении поста: ' . $e->getMessage();
}

header("Location: main.php");
exit();
?>