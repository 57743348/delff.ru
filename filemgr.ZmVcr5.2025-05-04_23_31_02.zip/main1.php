<?php
session_start();

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Update user's last activity time
$current_time = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("UPDATE users SET last_activity = ? WHERE user_id = ?");
$stmt->execute([$current_time, $_SESSION['user_id']]);

// Get number of online users (active in the last 5 minutes)
$online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
$online_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE last_activity > ?");
    $stmt->execute([$online_threshold]);
    $result = $stmt->fetch();
    $online_count = $result['count'];
} catch (PDOException $e) {
    // If error, keep counter at 0
}

// Get user data
$user = [];
try {
    $stmt = $pdo->prepare("SELECT username, avatar, bio, display_name, last_activity, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
}

// Get all posts with likes and comments count
$posts = [];
try {
    $stmt = $pdo->prepare("
        SELECT p.post_id, p.title, p.content, p.created_at, u.role,
               u.user_id, u.username, u.avatar, u.last_activity, u.display_name,
               COUNT(DISTINCT l.like_id) as likes_count,
               COUNT(DISTINCT c.comment_id) as comments_count,
               SUM(CASE WHEN l.user_id = ? THEN 1 ELSE 0 END) as is_liked
        FROM posts p
        JOIN users u ON p.user_id = u.user_id
        LEFT JOIN likes l ON p.post_id = l.post_id
        LEFT JOIN comments c ON p.post_id = c.post_id
        GROUP BY p.post_id
        ORDER BY p.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $posts = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении постов: ' . $e->getMessage();
}

// Function to check if user is online
function isUserOnline($last_activity) {
    $online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
    return $last_activity > $online_threshold;
}

// Function to get role class
function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    
    return isset($roles[$role]) ? $roles[$role] : 'user';
}
?>



<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interpol Organizations - Игровые читы и обсуждения</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Oswald', sans-serif;
        }

        body {
            background-color: #1a1a1a;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            flex: 1;
        }

        /* Header */
        .header {
            background-color: #272727;
            height: 45px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            border-bottom: 1px solid #3d3d3d;
            width: 100%;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-img {
            height: 30px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: 400;
            color: #fff;
        }

        .nav {
            display: flex;
            margin-left: 30px;
        }

        .nav-item {
            color: #fff;
            text-decoration: none;
            padding: 0 15px;
            font-size: 16px;
            transition: color 0.3s;
            height: 45px;
            display: flex;
            align-items: center;
        }

        .nav-item:hover {
            color: #ccc;
            background-color: #3d3d3d;
        }

        .user-profile {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #fff;
        }

        /* Main Content */
        .main-content {
            display: flex;
            min-height: calc(100vh - 45px);
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background-color: #272727;
            padding: 20px;
            border-right: 1px solid #3d3d3d;
        }

        .sidebar-section {
            margin-bottom: 30px;
        }

        .sidebar-title {
            color: #ccc;
            font-size: 18px;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 1px solid #3d3d3d;
        }

        .sidebar-item {
            color: #fff;
            display: block;
            padding: 8px 10px;
            margin-bottom: 5px;
            border-radius: 4px;
            text-decoration: none;
            transition: all 0.3s;
        }

        .sidebar-item:hover {
            background-color: #3d3d3d;
        }

        /* Новые стили для раскрывающихся кнопок */
        .dropdown-btn {
            background-color: #2d2d2d;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            border: none;
            text-align: left;
            cursor: pointer;
            border-radius: 4px;
            margin-bottom: 5px;
            transition: all 0.3s;
        }

        .dropdown-btn:hover {
            background-color: #3d3d3d;
        }

        .dropdown-btn.active {
            background-color: #3d3d3d;
            border-radius: 4px 4px 0 0;
            margin-bottom: 0;
        }

        .dropdown-btn::after {
            content: "▼";
            font-size: 12px;
        }

        .dropdown-btn.active::after {
            content: "▲";
        }

        .dropdown-container {
            display: none;
            background-color: #1e1e1e;
            padding: 0;
            border-radius: 0 0 4px 4px;
            margin-bottom: 5px;
            overflow: hidden;
        }

        .dropdown-container a {
            color: #fff;
            padding: 8px 20px;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }

        .dropdown-container a:hover {
            background-color: #333;
        }
        
        .create-post-btn {
            background-color: #fff;
            color: #000;
            display: block;
            width: 100%;
            padding: 10px;
            text-align: center;
            border-radius: 6px;
            font-size: 16px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .create-post-btn:hover {
            background-color: #e6e6e6;
        }

        /* Content Area */
        .content {
            flex: 1;
            padding: 20px;
            max-width: 900px;
        }

        /* Обновлённый стиль для панели сортировки */
        .sort-panel {
            background-color: #272727;
            padding: 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sort-dropdown {
            position: relative;
            display: inline-block;
        }

        .sort-button {
            background-color: #2d2d2d;
            color: #cfcfcf;
            padding: 8px 35px 8px 15px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            position: relative;
            transition: all 0.3s;
        }

        .sort-button:hover {
            background-color: #3d3d3d;
        }

        .sort-button::after {
            content: "▼";
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 12px;
        }

        .sort-dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d2d2d;
            min-width: 200px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 6px;
            overflow: hidden;
        }

        .sort-dropdown-content a {
            color: #cfcfcf;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .sort-dropdown-content a:hover {
            background-color: #3d3d3d;
        }

        .sort-dropdown:hover .sort-dropdown-content {
            display: block;
        }

        /* Кнопка обновления */
        .refresh-button {
            background-color: #2d2d2d;
            color: #cfcfcf;
            width: 36px;
            height: 36px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .refresh-button:hover {
            background-color: #3d3d3d;
        }

        /* Posts */
        .post {
            background-color: #272727;
            border-radius: 7px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .post-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #3d3d3d;
            margin-right: 10px;
        }

        .post-user {
            font-weight: 500;
        }

        .post-date {
            color: #ccc;
            font-size: 14px;
            margin-left: 10px;
        }

        .post-content {
            line-height: 1.5;
            margin-bottom: 15px;
        }

        .post-footer {
            display: flex;
            color: #ccc;
            font-size: 14px;
        }

        .post-action {
            margin-right: 20px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .post-action:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Header (полная ширина) -->
    <header class="header">
        <div class="logo">
            <img src="img/group-11-1.png" alt="Interpol Logo" class="logo-img">
            <div class="logo-text">Interpol organizations</div>
        </div>
        <nav class="nav">
            <a href="#" class="nav-item">Главная</a>
            <a href="#" class="nav-item">О нас</a>
            <a href="#" class="nav-item">Читы</a>
            <a href="#" class="nav-item">Обсуждение</a>
        </nav>
        <div class="user-profile">
            <div class="user-name">user</div>
            <div class="user-avatar"></div>
        </div>
    </header>

    <!-- Центрированный основной контент -->
    <div class="container">
        <div class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
                <button class="create-post-btn">Создать пост</button>
                 <a href="#" class="sidebar-item">Главаная</a>
                <div class="sidebar-section">
                    <div class="sidebar-title">Категории</div>
                    
                    <!-- Кнопка Dota 2 с выпадающим списком -->
                    <button class="dropdown-btn">Cheat</button>
                    <div class="dropdown-container">
                        <a href="#">Counter-Strike 2</a>
                        <a href="#">Roblox</a>
                        <a href="#">Остальное</a>
                        
                    </div>
                    
                    
                    <!-- Обычная ссылка -->
                    
                </div>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Обсуждение</div>
                    
               
                    
                    <!-- Обычная ссылка -->
                    <a href="#" class="sidebar-item">Предложения</a>
                </div>
            </aside>

            <!-- Content Area -->
            <main class="content">
                <div class="sort-panel">
                    <div class="sort-dropdown">
                        <button class="sort-button" id="sortButton">по дате создания</button>
                        <div class="sort-dropdown-content" id="sortDropdown">
                            <a href="#" onclick="changeSortOption('по дате создания')">по дате создания</a>
                            <a href="#" onclick="changeSortOption('по популярности')">по популярности</a>
                            <a href="#" onclick="changeSortOption('по комментариям')">по комментариям</a>
                        </div>
                    </div>
                    <button class="refresh-button" onclick="location.reload()">↻</button>
                </div>

                <!-- Posts -->
                <div class="post">
                    <div class="post-header">
                        <div class="post-avatar"></div>
                        <div class="post-user">Username</div>
                        <div class="post-date">2 часа назад</div>
                    </div>
                    <div class="post-content">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.
                    </div>
                    <div class="post-footer">
                        <div class="post-action">Нравится (24)</div>
                        <div class="post-action">Комментировать (5)</div>
                        <div class="post-action">Поделиться</div>
                    </div>
                </div>

                <div class="post">
                    <div class="post-header">
                        <div class="post-avatar"></div>
                        <div class="post-user">AnotherUser</div>
                        <div class="post-date">5 часов назад</div>
                    </div>
                    <div class="post-content">
                        Еще один пост для примера содержания. Здесь может быть полезная информация, обсуждение читов или просто разговор на игровые темы. Сообщество может комментировать и обсуждать этот пост.
                    </div>
                    <div class="post-footer">
                        <div class="post-action">Нравится (12)</div>
                        <div class="post-action">Комментировать (3)</div>
                        <div class="post-action">Поделиться</div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // Скрипт для выпадающего меню сортировки
        function changeSortOption(option) {
            document.getElementById('sortButton').textContent = option;
            // Здесь можно добавить логику для реальной сортировки контента
            event.preventDefault(); // Предотвращаем переход по ссылке
        }

        // Закрываем выпадающее меню при клике вне его
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('sortDropdown');
            const button = document.getElementById('sortButton');
            
            if (!dropdown.contains(event.target) && event.target !== button) {
                dropdown.style.display = 'none';
            }
        });
        
        // Скрипт для раскрывающихся кнопок в боковой панели
        const dropdownBtns = document.querySelectorAll(".dropdown-btn");
        
        dropdownBtns.forEach(btn => {
            btn.addEventListener("click", function() {
                this.classList.toggle("active");
                const dropdownContent = this.nextElementSibling;
                if (dropdownContent.style.display === "block") {
                    dropdownContent.style.display = "none";
                } else {
                    dropdownContent.style.display = "block";
                }
            });
        });
    </script>
</body>
</html>




во втором скрипте раскрывающаяся кнопка с игпами работает. сделай так чтобы и в первом скрипте она тоже работала взяв материалы из второго скрипта. и напиши готовый код полностью