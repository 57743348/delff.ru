<?php
session_start();

// Проверка авторизации и прав администратора
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Проверяем, является ли пользователь администратором
try {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user || $user['role'] !== 'admin') {
        $_SESSION['error'] = 'У вас нет прав для выполнения этого действия';
        header("Location: main.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при проверке прав доступа';
    header("Location: main.php");
    exit();
}

// Обработка формы редактирования
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Проверяем наличие обязательных полей
    if (!isset($_POST['post_id']) || !isset($_POST['title']) || !isset($_POST['content'])) {
        $_SESSION['error'] = 'Все поля обязательны для заполнения';
        header("Location: edit_post.php?id=" . $_POST['post_id']);
        exit();
    }
    
    $post_id = $_POST['post_id'];
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    
    // Валидация данных
    if (empty($title) || empty($content)) {
        $_SESSION['error'] = 'Заголовок и содержание не могут быть пустыми';
        header("Location: edit_post.php?id=" . $post_id);
        exit();
    }
    
    // Обновляем пост в базе данных
    try {
        $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ? WHERE post_id = ?");
        $stmt->execute([$title, $content, $post_id]);
        
        $_SESSION['success'] = 'Пост успешно обновлен';
        header("Location: post.php?id=" . $post_id);
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Ошибка при обновлении поста: ' . $e->getMessage();
        header("Location: edit_post.php?id=" . $post_id);
        exit();
    }
}

// Получение данных поста для редактирования
if (!isset($_GET['id'])) {
    $_SESSION['error'] = 'Не указан ID поста';
    header("Location: main.php");
    exit();
}

$post_id = $_GET['id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE post_id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    
    if (!$post) {
        $_SESSION['error'] = 'Пост не найден';
        header("Location: main.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных поста';
    header("Location: main.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Редактирование поста | Interpol</title>
  <style>
    body {
      background-color: black;
      color: white;
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background: rgba(30, 30, 30, 0.7);
      padding: 20px;
      border-radius: 8px;
    }
    h1 {
      margin-bottom: 20px;
    }
    .form-group {
      margin-bottom: 15px;
    }
    label {
      display: block;
      margin-bottom: 5px;
    }
    input[type="text"], textarea {
      width: 100%;
      padding: 10px;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid #444;
      border-radius: 4px;
      color: white;
    }
    textarea {
      min-height: 200px;
    }
    .btn {
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s;
      border: none;
    }
    .save-btn {
      background: rgba(0, 100, 255, 0.7);
      color: white;
    }
    .save-btn:hover {
      background: rgba(0, 100, 255, 0.9);
    }
    .cancel-btn {
      background: rgba(255, 255, 255, 0.1);
      color: white;
      margin-left: 10px;
    }
    .cancel-btn:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    .error {
      color: #ff5555;
      margin-bottom: 15px;
    }
    .success {
      color: #55ff55;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Редактирование поста</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
      <div class="error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
      <div class="success"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <form method="POST" action="edit_post.php">
      <input type="hidden" name="post_id" value="<?= htmlspecialchars($post['post_id']) ?>">
      
      <div class="form-group">
        <label for="title">Заголовок:</label>
        <input type="text" id="title" name="title" value="<?= htmlspecialchars($post['title']) ?>" required>
      </div>
      
      <div class="form-group">
        <label for="content">Содержание:</label>
        <textarea id="content" name="content" required><?= htmlspecialchars($post['content']) ?></textarea>
      </div>
      
      <div class="form-group">
        <button type="submit" class="btn save-btn">Сохранить изменения</button>
        <a href="post.php?id=<?= htmlspecialchars($post['post_id']) ?>" class="btn cancel-btn">Отмена</a>
      </div>
    </form>
  </div>
</body>
</html>