<?php
// Конфигурация
$SECRET_KEY = "6Ldf9BorAAAAAKwgM60nSY4r58G5SexaaIUibUjI";
$MIN_SCORE = 0.5; // Минимальный допустимый score

// Получаем данные из формы
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$message = $_POST['message'] ?? '';
$token = $_POST['recaptcha_token'] ?? '';
$remoteIp = $_SERVER['REMOTE_ADDR'];

// Проверяем наличие токена
if (empty($token)) {
    header("Location: main.php?error=Отсутствует токен reCAPTCHA");
    exit;
}

// Проверяем reCAPTCHA
$url = "https://www.google.com/recaptcha/api/siteverify";
$data = [
    'secret' => $SECRET_KEY,
    'response' => $token,
    'remoteip' => $remoteIp
];

$options = [
    'http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    ]
];

$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);
$result = json_decode($response, true);

// Анализ результата
if (!$result['success'] || $result['score'] < $MIN_SCORE || $result['action'] !== 'submit_form') {
    $error = "Проверка reCAPTCHA не пройдена. ";
    
    if (isset($result['error-codes'])) {
        $error .= "Ошибки: " . implode(', ', $result['error-codes']);
    } elseif ($result['score'] < $MIN_SCORE) {
        $error .= "Score слишком низкий: " . $result['score'];
    } elseif ($result['action'] !== 'submit_form') {
        $error .= "Неверное действие: " . $result['action'];
    }
    
    header("Location: main.php?error=" . urlencode($error));
    exit;
}

// Если всё успешно - обрабатываем форму
// Здесь можно сохранить данные в БД или отправить email
// Например:
$to = "your@email.com";
$subject = "Новое сообщение с сайта";
$body = "Имя: $name\nEmail: $email\nСообщение:\n$message";
mail($to, $subject, $body);

// Перенаправляем с сообщением об успехе
header("Location: main.php?success=1");
exit;
?>