<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Получаем информацию о пользователе
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    die("Ошибка при получении данных пользователя: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Личный кабинет</title>
    <link rel="icon" href="/uploads/favicon.ico">
  <style>
    body {
      background-color: black;
      color: white;
      font-family: Arial, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 50px;
    }
    .user-info {
      background: rgba(0, 0, 0, 0.7);
      padding: 20px;
      border-radius: 10px;
      border: 1px solid #333;
      margin-bottom: 20px;
      width: 80%;
      max-width: 600px;
    }
    .logout-btn {
      padding: 10px 20px;
      background: rgba(255, 0, 0, 0.3);
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .logout-btn:hover {
      background: rgba(255, 0, 0, 0.5);
    }
  </style>
</head>
<body>
  <div class="user-info">
    <h2>Добро пожаловать, <?= htmlspecialchars($user['username']) ?>!</h2>
    <p>Email: <?= htmlspecialchars($user['email'] ?? 'Не указан') ?></p>
    <p>Дата регистрации: <?= date('d.m.Y H:i', strtotime($user['created_at'])) ?></p>
  </div>
  
  <form action="logout.php" method="post">
    <button type="submit" class="logout-btn">Выйти</button>
  </form>
</body>
</html>