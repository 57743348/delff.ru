<?php
session_start();

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Update user's last activity time
$current_time = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("UPDATE users SET last_activity = ? WHERE user_id = ?");
$stmt->execute([$current_time, $_SESSION['user_id']]);

// Get number of online users (active in the last 5 minutes)
$online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
$online_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE last_activity > ?");
    $stmt->execute([$online_threshold]);
    $result = $stmt->fetch();
    $online_count = $result['count'];
} catch (PDOException $e) {
    // If error, keep counter at 0
}

// Get user data
$user = [];
try {
    $stmt = $pdo->prepare("SELECT username, avatar, bio, display_name, last_activity, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
}

// Get all posts with likes and comments count
$posts = [];
try {
    $stmt = $pdo->prepare("
        SELECT p.post_id, p.title, p.content, p.created_at, u.role,
               u.user_id, u.username, u.avatar, u.last_activity, u.display_name,
               COUNT(DISTINCT l.like_id) as likes_count,
               COUNT(DISTINCT c.comment_id) as comments_count,
               SUM(CASE WHEN l.user_id = ? THEN 1 ELSE 0 END) as is_liked
        FROM posts p
        JOIN users u ON p.user_id = u.user_id
        LEFT JOIN likes l ON p.post_id = l.post_id
        LEFT JOIN comments c ON p.post_id = c.post_id
        GROUP BY p.post_id
        ORDER BY p.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $posts = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении постов: ' . $e->getMessage();
}

// Function to check if user is online
function isUserOnline($last_activity) {
    $online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
    return $last_activity > $online_threshold;
}

// Function to get role class
function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    
    return isset($roles[$role]) ? $roles[$role] : 'user';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interpol Organizations - Игровые читы и обсуждения</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Oswald', sans-serif;
        }

        body {
            background-color: #1a1a1a;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            flex: 1;
        }
  /* Header */
        .header {
            background-color: #272727;
            height: 45px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            border-bottom: 1px solid #3d3d3d;
            width: 100%;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-img {
            height: 30px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: 400;
            color: #fff;
        }

        .nav {
            display: flex;
            margin-left: 30px;
        }

        .nav-item {
            color: #fff;
            text-decoration: none;
            padding: 0 15px;
            font-size: 16px;
            transition: color 0.3s;
            height: 45px;
            display: flex;
            align-items: center;
        }

        .nav-item:hover {
            color: #ccc;
            background-color: #3d3d3d;
        }



        .user-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #fff;
            position: relative;
        }

        .online-indicator {
            width: 8px;
            height: 8px;
            background-color: #4CAF50;
            border-radius: 50%;
            position: absolute;
            bottom: 0;
            right: 0;
            border: 1px solid #272727;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #272727;
            min-width: 150px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }

        .dropdown-menu a {
            color: #fff;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-menu a:hover {
            background-color: #3d3d3d;
        }



        .user-role {
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 3px;
        }

        .role-admin {
            background-color: #f44336;
        }

        .role-moderator {
            background-color: #2196F3;
        }

        .role-vip {
            background-color: #9C27B0;
        }

        .role-premium {
            background-color: #FF9800;
        }

        .role-helper {
            background-color: #4CAF50;
        }

        .role-designer {
            background-color: #E91E63;
        }

        .role-developer {
            background-color: #673AB7;
        }

        .role-tester {
            background-color: #00BCD4;
        }

        .role-writer {
            background-color: #009688;
        }

        .role-support {
            background-color: #8BC34A;
        }

        .role-guest {
            background-color: #757575;
        }

        .role-user {
            background-color: #607D8B;
        }

        /* Main Content */
        .main-content {
            display: flex;
            min-height: calc(100vh - 45px);
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background-color: #272727;
            padding: 20px;
            border-right: 1px solid #3d3d3d;
        }


        .sidebar-title {
            color: #ccc;
            font-size: 18px;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 1px solid #3d3d3d;
        }

        .sidebar-item {
            color: #fff;
            display: block;
            padding: 8px 10px;
            margin-bottom: 5px;
            border-radius: 4px;
            text-decoration: none;
            transition: all 0.3s;
        }

        .sidebar-item:hover {
            background-color: #3d3d3d;
        }

        /* Стили для раскрывающихся кнопок */
        .dropdown-btn {
            background-color: #272727;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            border: none;
            text-align: left;
            cursor: pointer;
            border-radius: 4px;
            margin-bottom: 5px;
            transition: all 0.3s;
        }

        .dropdown-btn:hover {
            background-color: #3d3d3d;
        }

        .dropdown-btn.active {
            background-color: #3d3d3d;
            border-radius: 4px 4px 0 0;
            margin-bottom: 0;
        }

        .dropdown-btn::after {
            content: "▼";
            font-size: 12px;
        }

        .dropdown-btn.active::after {
            content: "▲";
        }

        .dropdown-container {
            display: none;
            background-color: #1e1e1e;
            padding: 0;
            border-radius: 0 0 4px 4px;
            margin-bottom: 5px;
            overflow: hidden;
        }

        .dropdown-container a {
            color: #fff;
            padding: 8px 20px;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }

        .dropdown-container a:hover {
            background-color: #333;
        }
        
        .create-post-btn {
            background-color: #fff;
            color: #000;
            display: block;
            width: 100%;
            padding: 10px;
            text-align: center;
            border-radius: 6px;
            font-size: 16px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
            border: none;
        }

        .create-post-btn:hover {
            background-color: #e6e6e6;
        }

        /* Content Area */
        .content {
            flex: 1;
            padding: 20px;
            max-width: 900px;
        }

        /* Online counter */
        .online-counter {
            position: fixed;
            top: 200px;
            right: 20px;
            background-color: #272727;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            transition: background-color 0.3s;
            z-index: 100;
        }

        .online-counter-update {
            background-color: #3d3d3d;
        }

        /* Sort panel */
        .sort-panel {
            background-color: #272727;
            padding: 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sort-dropdown {
            position: relative;
            display: inline-block;
        }

        .sort-button {
            background-color: #2d2d2d;
            color: #cfcfcf;
            padding: 8px 35px 8px 15px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            position: relative;
            transition: all 0.3s;
        }

        .sort-button:hover {
            background-color: #3d3d3d;
        }

        .sort-button::after {
            content: "▼";
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 12px;
        }

        .sort-dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d2d2d;
            min-width: 200px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 6px;
            overflow: hidden;
        }

        .sort-dropdown-content a {
            color: #cfcfcf;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

ㅤㅤㅤㅤㅤㅤ
.sort-dropdown-content a:hover {
            background-color: #3d3d3d;
        }

        .sort-dropdown:hover .sort-dropdown-content {
            display: block;
        }

        /* Refresh button */
        .refresh-button {
            background-color: #2d2d2d;
            color: #cfcfcf;
            width: 36px;
            height: 36px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .refresh-button:hover {
            background-color: #3d3d3d;
        }

        /* Intro message */
        .intro-message {
            background-color: #272727;
            border-radius: 7px;
            padding: 20px;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .intro-message h2 {
            margin-bottom: 15px;
            color: #fff;
        }

        .intro-message p {
            margin-bottom: 10px;
            color: #ddd;
        }

        /* Posts */
        .post {
            background-color: #272727;
            border-radius: 7px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .post-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #3d3d3d;
            margin-right: 10px;
            position: relative;
            overflow: hidden;
        }

        .post-user {
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .post-date {
            color: #999;
            font-size: 14px;
            margin-left: auto;
        }

        .post-content {
            line-height: 1.6;
            color: #eee;
            margin-bottom: 20px;
            word-wrap: break-word;
        }

        .post-footer {
            display: flex;
            color: #ccc;
            font-size: 14px;
        }

        .post-action {
            margin-right: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
        }

        .post-action:hover {
            color: #fff;
        }

        .post-action i.liked {
            color: #f44336;
        }

        /* Credits section */
        .credits-section {
            background-color: #272727;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
            border-top: 1px solid #3d3d3d;
        }

        .credits-title {
            margin-bottom: 10px;
            color: #ccc;
        }
        .right-section {
    margin-left: auto;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
}

.user-role {
    display: inline-block;
    font-size: 0.7rem;
    padding: 2px 5px;
    border-radius: 3px;
    margin-right: 5px;
    text-transform: uppercase;
    font-weight: bold;
}

/* Стили для ролей */
.role-admin {
    background-color: #d32f2f;
    color: white;
    text-shadow: 0 0 5px rgba(255, 0, 0, 0.7);
}

.role-moderator {
    background-color: #7b1fa2;
    color: white;
    text-shadow: 0 0 5px rgba(180, 0, 255, 0.7);
}

.role-vip {
    background: linear-gradient(45deg, #ffc107, #ff9800);
    color: black;
    text-shadow: 0 0 5px rgba(255, 215, 0, 0.7);
}

.role-premium {
    background: linear-gradient(45deg, #4caf50, #8bc34a);
    color: white;
    text-shadow: 0 0 5px rgba(0, 255, 0, 0.7);
}

.role-helper {
    background-color: #0288d1;
    color: white;
    text-shadow: 0 0 5px rgba(0, 150, 255, 0.7);
}

.role-designer {
    background: linear-gradient(45deg, #e91e63, #9c27b0);
    color: white;
    text-shadow: 0 0 5px rgba(255, 0, 150, 0.7);
}

.role-developer {
    background-color: #607d8b;
    color: white;
    text-shadow: 0 0 5px rgba(100, 150, 200, 0.7);
}

.role-tester {
    background-color: #795548;
    color: white;
    text-shadow: 0 0 5px rgba(150, 100, 50, 0.7);
}

.role-writer {
    background: linear-gradient(45deg, #3f51b5, #2196f3);
    color: white;
    text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
}

.role-support {
    background: linear-gradient(45deg, #009688, #4caf50);
    color: white;
    text-shadow: 0 0 5px rgba(0, 255, 200, 0.7);
}

.role-guest {
    background-color: #9e9e9e;
    color: white;
    text-shadow: 0 0 5px rgba(200, 200, 200, 0.7);
}

.role-user {
    background-color: #1976d2;
    color: white;
    text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
}

.right-image {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    object-fit: cover;
    border: 1px solid #555;
    cursor: pointer;
    transition: transform 0.3s;
}

.right-image:hover {
    transform: scale(1.1);
}



.dropdown-menu1 {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    background: rgba(0, 0, 0, 0.9);
    border: 1px solid #333;
    border-radius: 5px;
    padding: 10px 0;
    min-width: 150px;
    z-index: 100;
}

.dropdown-menu1 a {
    display: block;
    padding: 8px 15px;
    font-size: 14px;
    color: white;
    text-decoration: none;
    white-space: nowrap;
}

.dropdown-menu1 a:hover {
    background: rgba(255, 255, 255, 0.1);
}

.right-section:hover .dropdown-menu1 {
    display: block;
}

@keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.3); opacity: 0.7; }
    100% { transform: scale(1); opacity: 1; }
}

        .credits-names {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 15px;
             color: #00d0d0;
        }

        .name-item a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .name-item a:hover {
            color: #aaa;
        }

        .tg-link {
            color: #0088cc;
            text-decoration: none;
            transition: color 0.3s;
        }

        .tg-link:hover {
            color: #006699;
        }

        @keyframes like {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <!-- Header (полная ширина) -->
   <header class="header">
       <div class="logo">
            <img src="dsdsd.png" alt="Interpol Logo" class="logo-img">
            <div class="logo-text">Interpol organizations</div>
        </div>
        <nav class="nav">
           
            <a href="#" class="nav-item">О нас</a>

        </nav>
           <!-- Online counter -->
    <div class="online-counter" id="onlineCounter">
        Онлайн: <?= $online_count ?>
    </div>
        <div class="right-section">
    <a href="profile.php" style="color: white; text-decoration: none;">
        <span class="user-role role-<?= getRoleClass($user['role']) ?>">
            <?= strtoupper($user['role']) ?>
        </span>
        <?= htmlspecialchars($user['display_name'] ?? 'Пользователь') ?>
    </a>
    <div style="position: relative;" data-user-id="<?= $_SESSION['user_id'] ?>">
        <img src="/uploads/<?= htmlspecialchars($user['avatar'] ?? '333.png') ?>" alt="Аватар" class="right-image">
        <span class="online-indicator"></span>
    </div>
    
    <!-- Dropdown menu -->
    <div class="dropdown-menu1">
        <a href="profile.php">Профиль</a>
        <a href="settings.php">Настройки</a>
        <a href="logout.php">Выйти</a>
    </div>
</div>
    </header>



    <!-- Центрированный основной контент -->
    <div class="container">
        <div class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
              <?php if ($user['role'] === 'admin' || $user['role'] === 'moderator' || $user['role'] === 'writer'): ?>
                    <button class="create-post-btn" onclick="window.location.href='addpost.php'">Создать пост</button>
                <?php endif; ?>
                
               
                <div class="sidebar-section">
                    <div class="sidebar-title">Категории</div>
                </div>
                 <a href="main.php" class="sidebar-item">Главная</a>
                <!-- Кнопка Cheat с выпадающим списком -->
                <button class="dropdown-btn">Cheat</button>
                <div class="dropdown-container">
                    <a href="cs2.php">Counter-Strike 2</a>
                    <a href="roblox.php">Roblox</a>
                    <a href="dota2.php">Dota 2</a>
                    <a href="#">Остальное</a>
                </div>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Обсуждение</div>
                    <a href="#" class="sidebar-item">Предложения</a>
                </div>
            </aside>

            <!-- Content Area -->
            <main class="content">
                <div class="sort-panel">

                    <button class="refresh-button" onclick="location.reload()">↻</button>
                </div>

                <!-- Intro message -->
                <div class="intro-message">
                    <h2>Добро пожаловать в Interpol Community</h2>
                    <p>
                        Здесь собираются лучшие умы, чтобы делиться идеями, опытом и создавать уникальное сообщество. 
                        Мы уважаем вклад каждого участника, и рады видеть тебя среди нас.
                    </p>
                    <p>
                        Присоединяйся к обсуждениям, читай интересные посты и не стесняйся выражать свои мысли. 
                        Помни, что каждый голос важен.
                    </p>
                </div>

ㅤㅤㅤㅤㅤ




<script>
    // Скрипт для выпадающего меню сортировки
    function toggleSortDropdown(event) {
        event.stopPropagation();
        const dropdown = document.getElementById('sortDropdown');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    function changeSortOption(option, event) {
        event.stopPropagation();
        document.getElementById('sortButton').textContent = option;
        document.getElementById('sortDropdown').style.display = 'none';
        // Здесь можно добавить логику для реальной сортировки контента
    }

    // Закрываем выпадающее меню при клике вне его
    document.addEventListener('click', function() {
        document.getElementById('sortDropdown').style.display = 'none';
    });

    // Скрипт для раскрывающихся кнопок в боковой панели
    document.querySelectorAll(".dropdown-btn").forEach(btn => {
        btn.addEventListener("click", function(event) {
            event.stopPropagation();
            this.classList.toggle("active");
            const dropdownContent = this.nextElementSibling;
            dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
        });
    });

    // Остальные функции (updateOnlineStatus, toggleLike) остаются без изменений
    function updateOnlineStatus() {
        fetch('update_activity.php')
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                const onlineCounter = document.getElementById('onlineCounter');
                if (onlineCounter) {
                    onlineCounter.textContent = `Онлайн: ${data.online_count}`;
                    onlineCounter.classList.add('online-counter-update');
                    setTimeout(() => {
                        onlineCounter.classList.remove('online-counter-update');
                    }, 1000);
                }
                
                document.querySelectorAll('.online-indicator').forEach(indicator => {
                    const parentDiv = indicator.closest('.post-avatar, .user-avatar');
                    if (parentDiv) {
                        const userId = parseInt(parentDiv.getAttribute('data-user-id') || <?= $_SESSION['user_id'] ?>);
                        if (data.online_users.includes(userId)) {
                            indicator.style.display = 'block';
                        } else {
                            indicator.style.display = 'none';
                        }
                    }
                });
            })
            .catch(error => console.error('Ошибка при обновлении статуса:', error));
    }

    function toggleLike(event, postId) {
        event.stopPropagation();
        
        const likeElement = event.currentTarget;
        const likeIcon = likeElement.querySelector('i');
        const likeCountElement = likeElement.querySelector('.like-count');
        let isLiked = likeIcon.classList.contains('liked');
        
        fetch('toggle_like.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `post_id=${postId}&action=${isLiked ? 'unlike' : 'like'}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                likeIcon.classList.toggle('liked');
                likeCountElement.textContent = data.likes_count;
                
                if (!isLiked) {
                    likeIcon.style.animation = 'like 0.5s';
                    setTimeout(() => {
                        likeIcon.style.animation = '';
                    }, 500);
                }
            } else {
                alert(data.message || 'Произошла ошибка');
            }
        })
        .catch(error => {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при обработке лайка');
        });
    }

    // Update online status every 30 seconds
    setInterval(updateOnlineStatus, 30000);
    updateOnlineStatus();
    
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            updateOnlineStatus();
        }
    });
</script>


</body>
</html>