<?php
session_start();

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Получаем данные текущего пользователя (для шапки)
$current_user = [];
$is_admin = false; // Флаг для проверки админских прав
try {
    $stmt = $pdo->prepare("SELECT username, avatar, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $current_user = $stmt->fetch();
    $is_admin = ($current_user['role'] === 'admin'); // Проверяем, является ли пользователь админом
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
    header("Location: main.php");
    exit();
}

// Получаем данные просматриваемого пользователя
$viewed_user = [];
if (isset($_GET['id'])) {
    try {
        // Добавляем поле last_ip в запрос
        $stmt = $pdo->prepare("SELECT user_id, username, avatar, bio, role, last_ip FROM users WHERE user_id = ?");
        $stmt->execute([$_GET['id']]);
        $viewed_user = $stmt->fetch();
        
        if (!$viewed_user) {
            $_SESSION['error'] = 'Пользователь не найден';
            header("Location: main.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Ошибка при получении данных пользователя';
        header("Location: main.php");
        exit();
    }
} else {
    $_SESSION['error'] = 'Не указан ID пользователя';
    header("Location: main.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Профиль <?= htmlspecialchars($viewed_user['username']) ?> | Interpol</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Фоновое изображение */
    .background-image {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) scale(0.7);
      width: 100vw;
      height: 100vh;
      z-index: -1;
      overflow: hidden;
      min-width: 800px;
      min-height: 800px;
    }

    .background-image img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: block;
      min-width: 800px;
      min-height: 800px;
    }
    
    body {
      background-color: black;
      font-family: Arial, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      color: white;
      overflow-x: hidden;
    }

    /* Верхняя панель */
    .top-bar {
      width: 100%;
      padding: 3vh 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: nowrap;
    }

    /* Ссылки слева */
    .left-links {
      margin-left: 2%;
      display: flex;
      gap: 3vw;
      align-items: center;
      flex-shrink: 1;
    }

    /* Правая секция */
    .right-section {
      margin-right: 2%;
      display: flex;
      gap: 2vw;
      align-items: center;
      flex-shrink: 0;
      position: relative;
    }

    /* Адаптивные текстовые ссылки */
    a {
      color: white;
      text-decoration: none;
      font-size: clamp(12px, 1.4vw, 20px);
      white-space: nowrap;
      transition: all 0.3s;
      padding: 0.5vh 0;
      position: relative;
    }

    a:hover {
      opacity: 0.8;
    }

    a:hover::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 1px;
      background: white;
      animation: underline 0.3s forwards;
    }

    @keyframes underline {
      from { width: 0 }
      to { width: 100% }
    }

    /* Адаптивная картинка */
    .right-image, .profile-avatar {
      width: clamp(30px, 3.5vw, 45px);
      height: clamp(30px, 3.5vw, 45px);
      border-radius: 50%;
      object-fit: cover;
      border: 1px solid #555;
      cursor: pointer;
      transition: transform 0.3s;
    }

    .right-image:hover, .profile-avatar:hover {
      transform: scale(1.1);
    }

    /* Выпадающее меню */
    .dropdown-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background: rgba(0, 0, 0, 0.9);
      border: 1px solid #333;
      border-radius: 5px;
      padding: 10px 0;
      min-width: 150px;
      display: none;
      z-index: 100;
    }

    .dropdown-menu a {
      display: block;
      padding: 8px 15px;
      font-size: 14px;
      color: white;
      text-decoration: none;
      white-space: nowrap;
    }

    .dropdown-menu a:hover {
      background: rgba(255, 255, 255, 0.1);
    }

    .right-section:hover .dropdown-menu {
      display: block;
    }

    /* Основное содержимое */
    .content {
      width: 80%;
      max-width: 800px;
      margin: 5vh auto;
      flex-grow: 1;
    }

    /* Профиль пользователя */
    .profile-container {
      background: rgba(30, 30, 30, 0.7);
      border-radius: 8px;
      padding: 30px;
      text-align: center;
    }

    .profile-avatar {
      width: 150px;
      height: 150px;
      margin: 0 auto 20px;
      border: 3px solid #555;
    }

    .profile-username {
      font-size: 1.8rem;
      margin-bottom: 20px;
      color: #fff;
    }

    .profile-bio {
      font-size: 1.1rem;
      line-height: 1.6;
      padding: 20px;
      background: rgba(0, 0, 0, 0.3);
      border-radius: 5px;
      white-space: pre-wrap;
      text-align: left;
    }

    .back-btn {
      background: rgba(255, 255, 255, 0.1);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s;
      margin-top: 30px;
    }

    .back-btn:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    /* Кнопки админа */
    .admin-actions {
      margin-top: 20px;
      display: flex;
      justify-content: center;
      gap: 15px;
      flex-wrap: wrap;
    }

    .admin-btn {
      background: rgba(255, 0, 0, 0.2);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .admin-btn:hover {
      background: rgba(255, 0, 0, 0.3);
    }

    .admin-btn.role-btn {
      background: rgba(0, 100, 255, 0.2);
    }

    .admin-btn.role-btn:hover {
      background: rgba(0, 100, 255, 0.3);
    }

    .admin-btn.ban-btn {
      background: rgba(255, 165, 0, 0.2);
    }

    .admin-btn.ban-btn:hover {
      background: rgba(255, 165, 0, 0.3);
    }

    /* Модальное окно */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }

    .modal-content {
      background: rgba(30, 30, 30, 0.9);
      padding: 30px;
      border-radius: 8px;
      width: 90%;
      max-width: 500px;
      max-height: 90vh;
      overflow-y: auto;
    }

    .modal-title {
      font-size: 1.5rem;
      margin-bottom: 20px;
      text-align: center;
    }

    .role-select {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      background: rgba(0, 0, 0, 0.5);
      color: white;
      border: 1px solid #555;
      border-radius: 5px;
    }

    .modal-buttons {
      display: flex;
      justify-content: center;
      gap: 15px;
    }

    .modal-btn {
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .modal-btn.confirm {
      background: rgba(0, 200, 0, 0.3);
      color: white;
      border: none;
    }

    .modal-btn.confirm:hover {
      background: rgba(0, 200, 0, 0.4);
    }

    .modal-btn.cancel {
      background: rgba(200, 0, 0, 0.3);
      color: white;
      border: none;
    }

    .modal-btn.cancel:hover {
      background: rgba(200, 0, 0, 0.4);
    }

    /* Адаптация для мобильных */
    @media (max-width: 768px) {
      .left-links {
        gap: 2vw;
      }
      a {
        font-size: clamp(10px, 3vw, 14px);
      }
      .right-image, .profile-avatar {
        width: clamp(25px, 6vw, 35px);
        height: clamp(25px, 6vw, 35px);
      }
      .dropdown-menu {
        min-width: 120px;
      }
      .content {
        width: 90%;
        padding: 0 15px;
      }
      .profile-container {
        padding: 20px;
      }
      .profile-avatar {
        width: 100px;
        height: 100px;
      }
      .profile-username {
        font-size: 1.4rem;
      }
      .admin-actions {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
</head>
<body>
<div class="background-image">
  <img src="1233.png" alt="Фоновое изображение">
</div>
<!-- Верхняя панель -->
<div class="top-bar">
  <div class="left-links">
    <a href="main.php">INTERPOL ORGANIZATIONS</a>
    <a href="main.php">Главная</a>
    <a href="https://t.me/+qHVi5eFtG_A1YTk6">О нас</a>
  </div>

  <div class="right-section">
    <a href="profile.php"><?= htmlspecialchars($current_user['username'] ?? 'Пользователь') ?></a>
    <img src="/uploads/<?= htmlspecialchars($current_user['avatar'] ?? '333.png') ?>" alt="Аватар" class="right-image">
    
    <!-- Выпадающее меню -->
    <div class="dropdown-menu">
      <a href="profile.php">Профиль</a>
      <a href="settings.php">Настройки</a>
      <a href="logout.php">Выйти</a>
    </div>
  </div>
</div>

<!-- Основное содержимое -->
<div class="content">
  <div class="profile-container">
    <img src="/uploads/<?= htmlspecialchars($viewed_user['avatar'] ?? '333.png') ?>" alt="Аватар" class="profile-avatar">
    <h1 class="profile-username"><?= htmlspecialchars($viewed_user['username']) ?>
      <small style="font-size: 0.6em; color: #aaa;">(<?= htmlspecialchars($viewed_user['role']) ?>)</small>
    </h1>
    
    <?php if (!empty($viewed_user['bio'])): ?>
      <div class="profile-bio"><?= nl2br(htmlspecialchars($viewed_user['bio'])) ?></div>
    <?php else: ?>
      <div class="profile-bio" style="color: #aaa;">Пользователь пока не добавил информацию о себе</div>
    <?php endif; ?>
    
    <?php if ($is_admin && $_GET['id'] != $_SESSION['user_id']): ?>
      <div class="admin-actions">
        <button class="admin-btn role-btn" onclick="openRoleModal()">Изменить роль</button>
        <button class="admin-btn" onclick="confirmDelete()">Удалить аккаунт</button>
        <button class="admin-btn ban-btn" onclick="confirmBan()">Заблокировать IP</button>
      </div>
    <?php endif; ?>
    
    <button class="back-btn" onclick="window.history.back()">Назад</button>
  </div>
</div>

<!-- Модальное окно для изменения роли -->
<div id="roleModal" class="modal">
  <div class="modal-content">
    <h2 class="modal-title">Изменить роль пользователя</h2>
    <select id="roleSelect" class="role-select">
      <option value="admin" <?= $viewed_user['role'] === 'admin' ? 'selected' : '' ?>>Администратор</option>
      <option value="moderator" <?= $viewed_user['role'] === 'moderator' ? 'selected' : '' ?>>Модератор</option>
      <option value="vip" <?= $viewed_user['role'] === 'vip' ? 'selected' : '' ?>>VIP</option>
      <option value="premium" <?= $viewed_user['role'] === 'premium' ? 'selected' : '' ?>>Премиум</option>
      <option value="helper" <?= $viewed_user['role'] === 'helper' ? 'selected' : '' ?>>Помощник</option>
      <option value="designer" <?= $viewed_user['role'] === 'designer' ? 'selected' : '' ?>>Дизайнер</option>
      <option value="developer" <?= $viewed_user['role'] === 'developer' ? 'selected' : '' ?>>Разработчик</option>
      <option value="tester" <?= $viewed_user['role'] === 'tester' ? 'selected' : '' ?>>Тестировщик</option>
      <option value="writer" <?= $viewed_user['role'] === 'writer' ? 'selected' : '' ?>>Писатель</option>
      <option value="support" <?= $viewed_user['role'] === 'support' ? 'selected' : '' ?>>Поддержка</option>
      <option value="guest" <?= $viewed_user['role'] === 'guest' ? 'selected' : '' ?>>Гость</option>
      <option value="small osint" <?= $viewed_user['role'] === 'small osint' ? 'selected' : '' ?>>Малый OSINT</option>
      <option value="user" <?= $viewed_user['role'] === 'user' ? 'selected' : '' ?>>Пользователь</option>
    </select>
    <div class="modal-buttons">
      <button class="modal-btn confirm" onclick="changeRole()">Подтвердить</button>
      <button class="modal-btn cancel" onclick="closeRoleModal()">Отмена</button>
    </div>
  </div>
</div>

<!-- Модальное окно для подтверждения удаления -->
<div id="deleteModal" class="modal">
  <div class="modal-content">
    <h2 class="modal-title">Подтверждение удаления</h2>
    <p style="text-align: center; margin-bottom: 20px;">Вы уверены, что хотите удалить аккаунт пользователя <?= htmlspecialchars($viewed_user['username']) ?>?</p>
    <div class="modal-buttons">
      <button class="modal-btn confirm" onclick="deleteAccount()">Да, удалить</button>
      <button class="modal-btn cancel" onclick="closeDeleteModal()">Отмена</button>
    </div>
  </div>
</div>

<!-- Модальное окно для блокировки IP -->
<div id="banModal" class="modal">
  <div class="modal-content">
    <h2 class="modal-title">Блокировка IP-адреса</h2>
    <p style="text-align: center; margin-bottom: 20px;">
      Вы собираетесь заблокировать IP-адрес <?= htmlspecialchars($viewed_user['last_ip'] ?? 'Неизвестно') ?> 
      (пользователь <?= htmlspecialchars($viewed_user['username']) ?>).
    </p>
    <div class="input-group">
      <label for="banReason" style="display: block; margin-bottom: 5px;">Причина блокировки (необязательно)</label>
      <textarea id="banReason" rows="3" style="width: 100%; padding: 10px; background: rgba(0, 0, 0, 0.5); color: white; border: 1px solid #555; border-radius: 5px; margin-bottom: 15px;"></textarea>
    </div>
    <div class="modal-buttons">
      <button class="modal-btn confirm" onclick="banIp()">Подтвердить</button>
      <button class="modal-btn cancel" onclick="closeBanModal()">Отмена</button>
    </div>
  </div>
</div>

<script>
  // Функции для работы с модальными окнами
  function openRoleModal() {
    document.getElementById('roleModal').style.display = 'flex';
  }

  function closeRoleModal() {
    document.getElementById('roleModal').style.display = 'none';
  }

  function confirmDelete() {
    document.getElementById('deleteModal').style.display = 'flex';
  }

  function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
  }
  
  // Функции для блокировки IP
  function confirmBan() {
    document.getElementById('banModal').style.display = 'flex';
  }

  function closeBanModal() {
    document.getElementById('banModal').style.display = 'none';
  }

  function banIp() {
    const reason = document.getElementById('banReason').value;
    const userId = <?= $viewed_user['user_id'] ?>;
    
    fetch('ban_ip.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `user_id=${userId}&reason=${encodeURIComponent(reason)}`
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('IP-адрес успешно заблокирован!');
        location.reload();
      } else {
        alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
      }
    })
    .catch(error => {
      alert('Ошибка сети: ' + error);
    });
    
    closeBanModal();
  }

  // AJAX-функция для изменения роли
  function changeRole() {
    const role = document.getElementById('roleSelect').value;
    const userId = <?= $viewed_user['user_id'] ?>;
    
    fetch('change_role.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `user_id=${userId}&role=${role}`
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('Роль успешно изменена!');
        location.reload();
      } else {
        alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
      }
    })
    .catch(error => {
      alert('Ошибка сети: ' + error);
    });
    
    closeRoleModal();
  }

  // AJAX-функция для удаления аккаунта
  function deleteAccount() {
    const userId = <?= $viewed_user['user_id'] ?>;
    
    fetch('delete_account.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `user_id=${userId}`
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('Аккаунт успешно удален!');
        window.location.href = 'main.php';
      } else {
        alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
      }
    })
    .catch(error => {
      alert('Ошибка сети: ' + error);
    });
    
    closeDeleteModal();
  }
</script>
</body>
</html>