<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

if (!isset($_GET['id']) || !isset($_GET['post_id'])) {
    $_SESSION['error'] = 'Не указан ID комментария или поста';
    header("Location: main.php");
    exit();
}

try {
    // Проверяем права пользователя
    $stmt = $pdo->prepare("
        SELECT c.user_id, u.role 
        FROM comments c
        JOIN users u ON c.user_id = u.user_id
        WHERE c.comment_id = ?
    ");
    $stmt->execute([$_GET['id']]);
    $comment = $stmt->fetch();
    
    if (!$comment) {
        $_SESSION['error'] = 'Комментарий не найден';
        header("Location: post.php?id=" . $_GET['post_id']);
        exit();
    }
    
    // Удалять может автор комментария или админ
    if ($comment['user_id'] != $_SESSION['user_id'] && $comment['role'] != 'admin') {
        $_SESSION['error'] = 'У вас нет прав для удаления этого комментария';
        header("Location: post.php?id=" . $_GET['post_id']);
        exit();
    }
    
    // Удаляем комментарий
    $stmt = $pdo->prepare("DELETE FROM comments WHERE comment_id = ?");
    $stmt->execute([$_GET['id']]);
    
    $_SESSION['success'] = 'Комментарий удален';
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при удалении комментария';
}

header("Location: post.php?id=" . $_GET['post_id']);
exit();
?>