<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("HTTP/1.1 403 Forbidden");
    exit(json_encode(['success' => false, 'message' => 'Доступ запрещен']));
}

require 'db_connect.php';

// Получаем данные из запроса
$suggestion_id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$suggestion_id) {
    header("HTTP/1.1 400 Bad Request");
    exit(json_encode(['success' => false, 'message' => 'Неверные параметры']));
}

try {
    // Проверяем права пользователя
    $stmt = $pdo->prepare("SELECT user_id FROM suggestions WHERE suggestion_id = ?");
    $stmt->execute([$suggestion_id]);
    $suggestion = $stmt->fetch();

    if (!$suggestion) {
        header("HTTP/1.1 404 Not Found");
        exit(json_encode(['success' => false, 'message' => 'Предложение не найдено']));
    }

    // Проверяем, является ли пользователь автором или админом
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user['role'] !== 'admin' && $suggestion['user_id'] != $_SESSION['user_id']) {
        header("HTTP/1.1 403 Forbidden");
        exit(json_encode(['success' => false, 'message' => 'Недостаточно прав']));
    }

    // Удаляем предложение
    $stmt = $pdo->prepare("DELETE FROM suggestions WHERE suggestion_id = ?");
    $stmt->execute([$suggestion_id]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    header("HTTP/1.1 500 Internal Server Error");
    echo json_encode(['success' => false, 'message' => 'Ошибка базы данных']);
}
?>