<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Обновление активности пользователя
$current_time = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("UPDATE users SET last_activity = ? WHERE user_id = ?");
$stmt->execute([$current_time, $_SESSION['user_id']]);

// Получение количества онлайн пользователей
$online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
$online_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE last_activity > ?");
    $stmt->execute([$online_threshold]);
    $result = $stmt->fetch();
    $online_count = $result['count'];
} catch (PDOException $e) {
    // Игнорируем ошибку
}

// Получение данных пользователя
$user = [];
try {
    $stmt = $pdo->prepare("SELECT username, avatar, bio, display_name, last_activity, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
}

// Проверка количества отправленных предложений пользователем
$user_suggestions_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM suggestions WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch();
    $user_suggestions_count = $result['count'];
} catch (PDOException $e) {
    // Игнорируем ошибку
}

function isUserOnline($last_activity) {
    $online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
    return $last_activity > $online_threshold;
}

function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    return $roles[$role] ?? 'user';
}

// Обработка отправки предложения
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['suggestion_text'])) {
        // Проверяем, не превысил ли пользователь лимит предложений
        if ($user_suggestions_count >= 2 && $user['role'] !== 'admin') {
            $_SESSION['error'] = 'Вы уже отправили максимальное количество предложений (2)';
        } else {
            $suggestion_text = trim($_POST['suggestion_text']);
            if (!empty($suggestion_text)) {
                try {
                    $stmt = $pdo->prepare("INSERT INTO suggestions (user_id, content, created_at) VALUES (?, ?, NOW())");
                    $stmt->execute([$_SESSION['user_id'], $suggestion_text]);
                    $_SESSION['success'] = 'Ваше предложение отправлено!';
                    header("Location: offers.php");
                    exit();
                } catch (PDOException $e) {
                    $_SESSION['error'] = 'Ошибка при отправке предложения';
                    error_log("Error adding suggestion: " . $e->getMessage());
                }
            }
        }
    }
    
    // Обработка действий с предложениями (принять/отклонить/удалить)
    if (isset($_POST['action']) && isset($_POST['request_id'])) {
        $action = $_POST['action'];
        $suggestion_id = $_POST['request_id'];
        
        try {
            // Проверяем, является ли пользователь админом или автором предложения
            $stmt = $pdo->prepare("SELECT user_id FROM suggestions WHERE suggestion_id = ?");
            $stmt->execute([$suggestion_id]);
            $suggestion = $stmt->fetch();
            
            if (!$suggestion) {
                $_SESSION['error'] = 'Предложение не найдено';
            } elseif ($user['role'] === 'admin' || $suggestion['user_id'] == $_SESSION['user_id']) {
                switch ($action) {
                    case 'approve':
                        $stmt = $pdo->prepare("UPDATE suggestions SET status = 'approved' WHERE suggestion_id = ?");
                        $stmt->execute([$suggestion_id]);
                        $_SESSION['success'] = 'Предложение принято';
                        break;
                    case 'reject':
                        $stmt = $pdo->prepare("UPDATE suggestions SET status = 'rejected' WHERE suggestion_id = ?");
                        $stmt->execute([$suggestion_id]);
                        $_SESSION['success'] = 'Предложение отклонено';
                        break;
                    case 'delete':
                        $stmt = $pdo->prepare("DELETE FROM suggestions WHERE suggestion_id = ?");
                        $stmt->execute([$suggestion_id]);
                        $_SESSION['success'] = 'Предложение удалено';
                        break;
                    default:
                        $_SESSION['error'] = 'Неизвестное действие';
                }
            } else {
                $_SESSION['error'] = 'У вас нет прав для выполнения этого действия';
            }
            
            header("Location: offers.php");
            exit();
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Ошибка при обработке запроса';
            error_log("Error processing suggestion action: " . $e->getMessage());
        }
    }
}

// Получаем все предложения
$suggestions = [];
try {
    $stmt = $pdo->prepare("
        SELECT s.suggestion_id, s.content, s.created_at, s.status, 
               u.user_id, u.username, u.avatar, u.display_name, u.role, u.last_activity
        FROM suggestions s
        JOIN users u ON s.user_id = u.user_id
        ORDER BY s.created_at DESC
    ");
    $stmt->execute();
    $suggestions = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении предложений';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Предложения по улучшению | Interpol Organizations</title>
  <link rel="icon" href="/uploads/favicon.ico">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Oswald', sans-serif;
    }

    body {
        background-color: #1a1a1a;
        color: #ffffff;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .container {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        flex: 1;
    }

    /* Header */
    .header {
        background-color: #272727;
        height: 45px;
        display: flex;
        align-items: center;
        padding: 0 20px;
        border-bottom: 1px solid #3d3d3d;
        width: 100%;
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .logo-img {
        height: 30px;
    }

    .logo-text {
        font-size: 20px;
        font-weight: 400;
        color: #fff;
    }

    .nav {
        display: flex;
        margin-left: 30px;
    }

    .nav-item {
        color: #fff;
        text-decoration: none;
        padding: 0 15px;
        font-size: 16px;
        transition: color 0.3s;
        height: 45px;
        display: flex;
        align-items: center;
    }

    .nav-item:hover {
        color: #ccc;
        background-color: #3d3d3d;
    }

    .right-section {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 10px;
        position: relative;
    }

    .user-role {
        display: inline-block;
        font-size: 0.7rem;
        padding: 2px 5px;
        border-radius: 3px;
        margin-right: 5px;
        text-transform: uppercase;
        font-weight: bold;
    }

    /* Стили для ролей */
    .role-admin {
        background-color: #d32f2f;
        color: white;
    }

    .role-moderator {
        background-color: #7b1fa2;
        color: white;
    }

    .role-vip {
        background-color: #ff9800;
        color: white;
    }

    .role-premium {
        background-color: #2196F3;
        color: white;
    }

    .role-helper {
        background-color: #4CAF50;
        color: white;
    }

    .role-designer {
        background-color: #9C27B0;
        color: white;
    }

    .role-developer {
        background-color: #607D8B;
        color: white;
    }

    .role-tester {
        background-color: #795548;
        color: white;
    }

    .role-writer {
        background-color: #3F51B5;
        color: white;
    }

    .role-support {
        background-color: #009688;
        color: white;
    }

    .role-guest {
        background-color: #9E9E9E;
        color: white;
    }

    .role-user {
        background-color: #1976d2;
        color: white;
    }

    .right-image {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid #555;
        cursor: pointer;
        transition: transform 0.3s;
    }

    .right-image:hover {
        transform: scale(1.1);
    }

    .dropdown-menu1 {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        background: rgba(0, 0, 0, 0.9);
        border: 1px solid #333;
        border-radius: 5px;
        padding: 10px 0;
        min-width: 150px;
        z-index: 100;
    }

    .dropdown-menu1 a {
        display: block;
        padding: 8px 15px;
        font-size: 14px;
        color: white;
        text-decoration: none;
        white-space: nowrap;
    }

    .dropdown-menu1 a:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    .right-section:hover .dropdown-menu1 {
        display: block;
    }

    /* Online counter */
    .online-counter {
        position: fixed;
        top: 60px;
        right: 20px;
        background-color: #272727;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 14px;
        z-index: 100;
    }

    /* Main Content */
    .main-content {
        display: flex;
        min-height: calc(100vh - 45px);
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
    }

    /* Sidebar */
    .sidebar {
        width: 280px;
        background-color: rgba(39, 39, 39, 0.7);
        padding: 20px;
        border-right: 1px solid #3d3d3d;
    }

    .sidebar-title {
        color: #ccc;
        font-size: 18px;
        margin-bottom: 15px;
        padding-bottom: 5px;
        border-bottom: 1px solid #3d3d3d;
    }

    .sidebar-item {
        color: #fff;
        display: block;
        padding: 8px 10px;
        margin-bottom: 5px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.3s;
    }

    .sidebar-item:hover {
        background-color: #3d3d3d;
    }

    /* Стили для раскрывающихся кнопок */
    .dropdown-btn {
        background-color: rgba(39, 39, 39, 0);
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
        width: 100%;
        border: none;
        text-align: left;
        cursor: pointer;
        border-radius: 4px;
        margin-bottom: 5px;
        transition: all 0.3s;
    }

    .dropdown-btn:hover {
        background-color: #3d3d3d;
    }

    .dropdown-btn.active {
        background-color: #3d3d3d;
        border-radius: 4px 4px 0 0;
        margin-bottom: 0;
    }

    .dropdown-btn::after {
        content: "▼";
        font-size: 12px;
    }

    .dropdown-btn.active::after {
        content: "▲";
    }

    .dropdown-container {
        display: none;
        background-color: #1e1e1e;
        padding: 0;
        border-radius: 0 0 4px 4px;
        margin-bottom: 5px;
        overflow: hidden;
    }

    .dropdown-container a {
        color: #fff;
        padding: 8px 20px;
        text-decoration: none;
        display: block;
        transition: all 0.3s;
    }

    .dropdown-container a:hover {
        background-color: #333;
    }
    
    .create-post-btn {
        background-color: #fff;
        color: #000;
        display: block;
        width: 100%;
        padding: 10px;
        text-align: center;
        border-radius: 6px;
        font-size: 16px;
        margin-bottom: 20px;
        cursor: pointer;
        transition: background-color 0.3s;
        border: none;
    }

    .create-post-btn:hover {
        background-color: #e6e6e6;
    }

.content {
    flex: 1;
    background-color: rgba(39, 39, 39, 0.7);
    border-radius: 7px;
    padding: 20px;
    margin-right: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

    /* Suggestions section */
    .suggestions-section {
        background-color: #272727;
        border-radius: 7px;
        padding: 20px;
        margin-bottom: 20px;
    }

    .suggestions-title {
        font-size: 20px;
        margin-bottom: 15px;
        color: #fff;
    }

    .suggestion-form {
        margin-bottom: 20px;
    }

    .suggestion-textarea {
        width: 100%;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #3d3d3d;
        background-color: #2d2d2d;
        color: #fff;
        min-height: 100px;
        margin-bottom: 10px;
        resize: vertical;
    }

    .suggestion-submit {
        background-color: #1976d2;
        color: #fff;
        padding: 8px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .suggestion-submit:hover {
        background-color: #1565c0;
    }

    .suggestion-list {
        margin-top: 20px;
    }

    .suggestion-item {
        background-color: #2d2d2d;
        border-radius: 4px;
        padding: 15px;
        margin-bottom: 15px;
        border-left: 4px solid #3d3d3d;
    }

    .suggestion-item.pending {
        border-left-color: #ffc107;
    }

    .suggestion-item.approved {
        border-left-color: #4CAF50;
    }

    .suggestion-item.rejected {
        border-left-color: #f44336;
    }

    .suggestion-header {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }

    .suggestion-avatar {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-right: 10px;
        position: relative;
    }

    .suggestion-author {
        font-weight: 500;
        margin-right: 10px;
    }

    .suggestion-date {
        color: #999;
        font-size: 12px;
        margin-left: auto;
    }

    .suggestion-status {
        font-size: 12px;
        padding: 2px 5px;
        border-radius: 3px;
        margin-left: 10px;
    }

    .status-pending {
        background-color: #ffc107;
        color: #000;
    }

    .status-approved {
        background-color: #4CAF50;
        color: #fff;
    }

    .status-rejected {
        background-color: #f44336;
        color: #fff;
    }

    .suggestion-content {
        line-height: 1.5;
        color: #eee;
        margin-bottom: 10px;
        word-wrap: break-word;
        white-space: pre-line;
    }

    .suggestion-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }

    .suggestion-action {
        background: none;
        border: none;
        color: #999;
        font-size: 12px;
        cursor: pointer;
        transition: color 0.3s;
        padding: 0;
    }

    .suggestion-action:hover {
        color: #fff;
    }

    /* Messages */
    .message {
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
    }

    .error {
        background-color: #d32f2f;
        color: #fff;
    }

    .success {
        background-color: #388e3c;
        color: #fff;
    }

    /* Background image */
    .background-image {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.7);
        width: 100vw;
        height: 100vh;
        z-index: -1;
        overflow: hidden;
        min-width: 800px;
        min-height: 800px;
    }
    
    .glow-hover {
        color: #fff;
        transition: text-shadow 0.3s ease;
        text-shadow: 0 0 8px white, 0 0 16px white;
    }

    .background-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
        min-width: 800px;
        min-height: 800px;
    }

    .online-indicator {
        width: 8px;
        height: 8px;
        background-color: #4CAF50;
        border-radius: 50%;
        position: absolute;
        bottom: 0;
        right: 0;
        border: 1px solid #272727;
    }

    .role-badge {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 12px;
        font-weight: bold;
        margin-left: 5px;
    }
  </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="dsdsd.png" alt="Interpol Logo" class="logo-img">
            <div class="logo-text">Interpol organizations</div>
        </div>
        <nav class="nav">
            <a href="onas.php" class="nav-item">О нас</a>
        </nav>
        
        <!-- Online counter -->
        <div class="online-counter" id="onlineCounter">
            Онлайн: <?= $online_count ?>
        </div>
        
        <div class="right-section">
            <a href="profile.php" style="color: white; text-decoration: none;">
                <span class="user-role role-<?= getRoleClass($user['role']) ?>">
                    <?= strtoupper($user['role']) ?>
                </span>
                <?= htmlspecialchars($user['display_name'] ?? 'Пользователь') ?>
            </a>
            <div style="position: relative;" data-user-id="<?= $_SESSION['user_id'] ?>">
                <img src="/uploads/<?= htmlspecialchars($user['avatar'] ?? '333.png') ?>" alt="Аватар" class="right-image">
                <span class="online-indicator" style="display: <?= isUserOnline($user['last_activity']) ? 'block' : 'none' ?>;"></span>
            </div>
            
            <!-- Dropdown menu -->
            <div class="dropdown-menu1">
                <a href="profile.php">Профиль</a>
                <a href="settings.php">Настройки</a>
                <a href="logout.php">Выйти</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="main-content">
            <aside class="sidebar">
                <button class="create-post-btn" onclick="window.location.href='addpost.php'">Создать пост</button>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Категории</div>
                </div>
                <a href="main.php" class="sidebar-item">Главная</a>
                <!-- Кнопка Cheat с выпадающим списком -->
                <button class="dropdown-btn">Cheat</button>
                <div class="dropdown-container">
                    <a href="cs2.php">Counter-Strike 2</a>
                    <a href="roblox.php">Roblox</a>
                    <a href="dota2.php">Dota 2</a>
                    <a href="other.php">Остальное</a>
                </div>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Обсуждение</div>
                    <a href="offers.php" class="sidebar-item glow-hover">Предложения</a>
                    <a href="addrole.php" class="sidebar-item">Заявки на роль</a>
                </div>
            </aside>

            <!-- Content Area -->
            <main class="content">
                <!-- Suggestions section -->
                <div class="suggestions-section">
                    <h2 class="suggestions-title">Предложения по улучшению</h2>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="message error"><?= $_SESSION['error'] ?></div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="message success"><?= $_SESSION['success'] ?></div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <!-- Suggestion form -->
                   <form class="suggestion-form" method="POST">
                        <textarea name="suggestion_text" class="suggestion-textarea" placeholder="Опишите ваше предложение по улучшению сайта..." required></textarea>
                        <?php if ($user_suggestions_count < 2 || $user['role'] === 'admin'): ?>
                            <button type="submit" class="suggestion-submit">Отправить предложение</button>
                        <?php else: ?>
                            <div class="message error">Вы уже отправили максимальное количество предложений (2)</div>
                        <?php endif; ?>
                    </form>
                    
                    <!-- Suggestions list -->
                    <div class="suggestion-list">
                        <?php if (empty($suggestions)): ?>
                            <div class="suggestion-item">Пока нет предложений. Будьте первым!</div>
                        <?php else: ?>
                            <?php foreach ($suggestions as $suggestion): ?>
                                <div class="suggestion-item <?= $suggestion['status'] ?>">
                                    <div class="suggestion-header">
                                        <div class="suggestion-avatar" data-user-id="<?= $suggestion['user_id'] ?>">
                                            <img src="/uploads/<?= htmlspecialchars($suggestion['avatar'] ?? '333.png') ?>" alt="Аватар" style="width:100%;height:100%;object-fit:cover;">
                                            <span class="online-indicator" style="display: <?= isUserOnline($suggestion['last_activity']) ? 'block' : 'none' ?>;"></span>
                                        </div>
                                        <div class="suggestion-author">
                                            <?= htmlspecialchars($suggestion['display_name']) ?>
                                            <span class="role-badge role-<?= getRoleClass($suggestion['role']) ?>">
                                                <?= strtoupper($suggestion['role']) ?>
                                            </span>
                                        </div>
                                        <span class="suggestion-status status-<?= $suggestion['status'] ?>">
                                            <?= $suggestion['status'] === 'pending' ? 'На рассмотрении' : 
                                               ($suggestion['status'] === 'approved' ? 'Принято' : 'Отклонено') ?>
                                        </span>
                                        <div class="suggestion-date">
                                            <?= date('d.m.Y H:i', strtotime($suggestion['created_at'])) ?>
                                        </div>
                                    </div>
                                    
                                    <div class="suggestion-content">
                                        <?= nl2br(htmlspecialchars($suggestion['content'])) ?>
                                    </div>
                                    
                                    <?php if ($user['role'] === 'admin' || $suggestion['user_id'] == $_SESSION['user_id']): ?>
                                        <div class="suggestion-actions">
                                            <?php if ($user['role'] === 'admin' && $suggestion['status'] === 'pending'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?= $suggestion['suggestion_id'] ?>">
                                                    <input type="hidden" name="action" value="approve">
                                                    <button type="submit" class="suggestion-action">Принять</button>
                                                </form>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?= $suggestion['suggestion_id'] ?>">
                                                    <input type="hidden" name="action" value="reject">
                                                    <button type="submit" class="suggestion-action">Отклонить</button>
                                                </form>
                                            <?php endif; ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="request_id" value="<?= $suggestion['suggestion_id'] ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" class="suggestion-action" onclick="return confirm('Вы уверены, что хотите удалить это предложение?')">Удалить</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Background image -->
    <div class="background-image">
        <img src="123333.png" alt="Фоновое изображение">
    </div>

    <script>
    // Функция для обновления онлайн статуса
    function updateOnlineStatus() {
        fetch('update_activity.php')
            .then(response => response.json())
            .then(data => {
                const onlineCounter = document.getElementById('onlineCounter');
                if (onlineCounter) {
                    onlineCounter.textContent = `Онлайн: ${data.online_count}`;
                }
                
                document.querySelectorAll('.online-indicator').forEach(indicator => {
                    const parentDiv = indicator.closest('[data-user-id]');
                    if (parentDiv) {
                        const userId = parseInt(parentDiv.getAttribute('data-user-id'));
                        if (data.online_users.includes(userId)) {
                            indicator.style.display = 'block';
                        } else {
                            indicator.style.display = 'none';
                        }
                    }
                });
            })
            .catch(error => console.error('Ошибка при обновлении статуса:', error));
    }

    // Initialize
    updateOnlineStatus();
    
    // Обновляем онлайн статус при возвращении на страницу
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            updateOnlineStatus();
        }
    });

    // Обновляем онлайн статус каждые 30 секунд
    setInterval(updateOnlineStatus, 30000);

    // Обработка отправки формы предложения
    document.querySelector('.suggestion-form')?.addEventListener('submit', function(e) {
        const textarea = this.querySelector('textarea');
        if (textarea.value.trim().length === 0) {
            e.preventDefault();
            alert('Предложение не может быть пустым');
        }
    });
    
    // Скрипт для раскрывающихся кнопок в боковой панели
    document.querySelectorAll(".dropdown-btn").forEach(btn => {
        btn.addEventListener("click", function(event) {
            event.stopPropagation();
            this.classList.toggle("active");
            const dropdownContent = this.nextElementSibling;
            dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
        });
    });
    </script>
</body>
</html>