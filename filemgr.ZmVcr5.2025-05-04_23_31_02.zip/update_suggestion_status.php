<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("HTTP/1.1 403 Forbidden");
    exit(json_encode(['success' => false, 'message' => 'Доступ запрещен']));
}

require 'db_connect.php';

// Проверяем роль пользователя
$stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($user['role'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit(json_encode(['success' => false, 'message' => 'Недостаточно прав']));
}

// Получаем данные из запроса
$suggestion_id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

if (!$suggestion_id || !in_array($status, ['approved', 'rejected'])) {
    header("HTTP/1.1 400 Bad Request");
    exit(json_encode(['success' => false, 'message' => 'Неверные параметры']));
}

try {
    // Обновляем статус предложения
    $stmt = $pdo->prepare("UPDATE suggestions SET status = ? WHERE suggestion_id = ?");
    $stmt->execute([$status, $suggestion_id]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    header("HTTP/1.1 500 Internal Server Error");
    echo json_encode(['success' => false, 'message' => 'Ошибка базы данных']);
}
?>