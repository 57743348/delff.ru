<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Доступ запрещен</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background-color: black;
      font-family: Arial, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
      padding: 20px;
    }

    .ban-container {
      max-width: 600px;
      padding: 40px;
      background: rgba(255, 0, 0, 0.1);
      border: 1px solid rgba(255, 0, 0, 0.3);
      border-radius: 10px;
    }

    h1 {
      color: #ff4444;
      margin-bottom: 20px;
      font-size: 2rem;
    }

    p {
      margin-bottom: 30px;
      font-size: 1.1rem;
      line-height: 1.6;
    }

    .contact {
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    a {
      color: #aaa;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="ban-container">
    <h1>Доступ запрещен</h1>
    <p>Ваш IP-адрес был заблокирован администрацией сайта. Вы не можете войти или зарегистрировать новый аккаунт.</p>
    <p>Если вы считаете, что это ошибка, пожалуйста, свяжитесь с администрацией.</p>
    
    <div class="contact">
      <p>Контакты для связи: <a href="mailto:admin@example.com">admin@example.com</a></p>
    </div>
  </div>
</body>
</html>