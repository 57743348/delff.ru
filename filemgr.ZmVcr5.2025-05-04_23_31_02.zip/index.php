<?php
ob_start();
session_start();
require 'db_connect.php';

// Функция для получения реального IP пользователя
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Функция для проверки IP на бан
function isIpBanned($ip) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT id FROM banned_ips WHERE ip_address = ?");
        $stmt->execute([$ip]);
        return (bool)$stmt->fetch();
    } catch (PDOException $e) {
        error_log('Error checking banned IP: ' . $e->getMessage());
        return false;
    }
}

// Улучшенная функция проверки reCAPTCHA с использованием cURL
function verifyRecaptcha($response) {
    $secret = '6LfF8xorAAAAAIqPtp2iPR4HAbo3pP2Tc6XO7cJy';
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, [
        'secret' => $secret,
        'response' => $response,
        'remoteip' => getClientIP()
    ]);
    
    $result = curl_exec($curl);
    $error = curl_error($curl);
    
    if ($error) {
        error_log('reCAPTCHA cURL error: ' . $error);
        return false;
    }
    
    curl_close($curl);
    
    $response = json_decode($result);
    
    if (!$response || !isset($response->success)) {
        error_log('reCAPTCHA verification failed: invalid response from Google: ' . $result);
        return false;
    }
    
    if ($response->success !== true) {
        if (isset($response->{'error-codes'}) && is_array($response->{'error-codes'})) {
            error_log('reCAPTCHA errors: ' . json_encode($response->{'error-codes'}));
        }
    }
    
    return $response->success;
}

// Обработка форм
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'login') {
            handleLogin();
        } elseif ($_POST['action'] === 'register') {
            handleRegister();
        }
    }
}

function handleLogin() {
    global $pdo;
    
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $ip = getClientIP();
    
    if (isIpBanned($ip)) {
        $_SESSION['error'] = 'Ваш IP-адрес заблокирован. Доступ запрещен.';
        header("Location: banned.php");
        exit();
    }
    
    if (empty($username) || empty($password)) {
        $_SESSION['error'] = 'Все поля должны быть заполнены';
        $_SESSION['show_login'] = true;
        return;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT user_id, username FROM users WHERE last_ip = ? AND username != ?");
        $stmt->execute([$ip, $username]);
        $existing_user = $stmt->fetch();
        
        if ($existing_user) {
            $_SESSION['error'] = 'С вашего IP-адреса уже зарегистрирован аккаунт с логином:'.htmlspecialchars($existing_user['username']).'. Вы не можете войти в другой аккаунт.';
            $_SESSION['show_login'] = true;
            return;
        }
        
        $stmt = $pdo->prepare("SELECT user_id, username, password_hash, last_ip FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password_hash'])) {
            if ($user['last_ip'] !== $ip) {
                $_SESSION['error'] = 'Вход запрещен. Вы пытаетесь войти с другого IP-адреса.';
                $_SESSION['show_login'] = true;
                return;
            }
            
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            
            $stmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE user_id = ?");
            $stmt->execute([$user['user_id']]);
            
            header("Location: https://delff.ru/main.php");
            exit();
        } else {
            $_SESSION['error'] = 'Неверное имя пользователя или пароль';
            $_SESSION['show_login'] = true;
        }
    } catch (PDOException $e) {
        error_log('Login error: ' . $e->getMessage());
        $_SESSION['error'] = 'Ошибка при входе в систему';
        $_SESSION['show_login'] = true;
    }
}

function handleRegister() {
    global $pdo;
    
    $username = trim($_POST['username'] ?? '');
    $display_name = trim($_POST['display_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $ip = getClientIP();
    $recaptcha_response = $_POST['g-recaptcha-response'] ?? '';
    
    error_log('Registration attempt from IP: ' . $ip . ' with username: ' . $username);
    
    if (isIpBanned($ip)) {
        $_SESSION['error'] = 'Ваш IP-адрес заблокирован. Регистрация невозможна.';
        header("Location: banned.php");
        exit();
    }
    
    if (empty($username) || empty($display_name) || empty($password) || empty($confirm_password)) {
        $_SESSION['error'] = 'Все поля должны быть заполнены';
        $_SESSION['show_register'] = true;
        return;
    }
    
    if ($password !== $confirm_password) {
        $_SESSION['error'] = 'Пароли не совпадают';
        $_SESSION['show_register'] = true;
        return;
    }
    
    if (empty($recaptcha_response)) {
        $_SESSION['error'] = 'Пожалуйста, подтвердите, что вы не робот';
        $_SESSION['show_register'] = true;
        return;
    }
    
    error_log('Attempting reCAPTCHA verification with response token: ' . substr($recaptcha_response, 0, 20) . '...');
    
    $recaptcha_valid = verifyRecaptcha($recaptcha_response);
    if (!$recaptcha_valid) {
        $_SESSION['error'] = 'Ошибка проверки reCAPTCHA. Пожалуйста, попробуйте снова.';
        $_SESSION['show_register'] = true;
        return;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->fetch()) {
            $_SESSION['error'] = 'Имя пользователя уже занято';
            $_SESSION['show_register'] = true;
            return;
        }
        
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE last_ip = ?");
        $stmt->execute([$ip]);
        
        if ($stmt->fetch()) {
            $_SESSION['error'] = 'С вашего IP-адреса уже зарегистрирован аккаунт';
            $_SESSION['show_register'] = true;
            return;
        }
        
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, display_name, password_hash, last_ip) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $display_name, $password_hash, $ip]);
        
        $user_id = $pdo->lastInsertId();
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['display_name'] = $display_name;
        
        error_log('User registered successfully: ' . $username . ' (ID: ' . $user_id . ')');
        
        header("Location: https://delff.ru/main.php");
        exit();
    } catch (PDOException $e) {
        error_log('Registration error: ' . $e->getMessage());
        $_SESSION['error'] = 'Ошибка при регистрации: ' . $e->getMessage();
        $_SESSION['show_register'] = true;
    }
}

// Функция для получения класса роли
function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    
    return isset($roles[$role]) ? $roles[$role] : 'user';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="/uploads/favicon.ico">
  <title>Панель входа - Interpol organizations</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Oswald', sans-serif;
    }

    body {
      background-color: #1a1a1a;
      color: #ffffff;
      min-height: 100vh;
      position: relative;
      overflow-x: hidden;
    }


    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-img {
      height: 30px;
    }

    .logo-text {
      font-size: 20px;
      font-weight: 400;
      color: #fff;
    }

    /* Auth Panel */
    .auth-panel {
      margin: 15vh auto 0;
      width: clamp(300px, 30vw, 400px);
      padding: 3vh 2vw;
      background: rgba(39, 39, 39, 0.9);
      border-radius: 7px;
      border: 1px solid #3d3d3d;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
    }

    .auth-title {
      text-align: center;
      font-size: clamp(18px, 2vw, 24px);
      margin-bottom: 3vh;
    }

    .auth-form {
      display: flex;
      flex-direction: column;
      gap: 2vh;
    }

    .input-group {
      display: flex;
      flex-direction: column;
      gap: 0.5vh;
    }

    .input-group label {
      font-size: clamp(14px, 1.2vw, 16px);
    }

    .input-group input {
      padding: 12px 16px;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid #555;
      border-radius: 5px;
      color: white;
      font-size: clamp(14px, 1.2vw, 16px);
    }

    .auth-buttons {
      display: flex;
      justify-content: space-between;
      margin-top: 2vh;
      gap: 12px;
    }

    .auth-btn {
      padding: 12px 5px;
      background: linear-gradient(to bottom, rgba(255,255,255,0.25), rgba(255,255,255,0.15));
      color: white;
      border: 1px solid rgba(255,255,255,0.2);
      border-radius: 6px;
      cursor: pointer;
      font-size: 13px;
      transition: all 0.3s ease;
      flex: 1;
      min-width: 0;
      text-align: center;
      display: flex;
      align-items: center;
      justify-content: center;
      white-space: nowrap;
      height: 42px;
    }

    .auth-btn:hover {
      background: linear-gradient(to bottom, rgba(255,255,255,0.35), rgba(255,255,255,0.25));
      border-color: rgba(255,255,255,0.3);
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .auth-btn:active {
      transform: translateY(0);
      box-shadow: none;
    }

    .auth-link {
      color: #aaa;
      text-align: center;
      margin-top: 2vh;
      font-size: clamp(12px, 1vw, 14px);
    }

    .auth-link a {
      color: #ddd;
      text-decoration: none;
    }

    .auth-link a:hover {
      text-decoration: underline;
    }

    .message {
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      text-align: center;
    }

    .error {
      background-color: rgba(255, 0, 0, 0.2);
      border: 1px solid rgba(255, 0, 0, 0.5);
    }

    .success {
      background-color: rgba(0, 255, 0, 0.2);
      border: 1px solid rgba(0, 255, 0, 0.5);
    }

    .register-form {
      display: none;
    }

    .g-recaptcha {
      margin: 15px 0;
      display: flex;
      justify-content: center;
    }

    /* Role classes */
    .user-role {
      font-size: 12px;
      padding: 2px 6px;
      border-radius: 3px;
      text-transform: uppercase;
      font-weight: bold;
    }

    .role-admin {
      background-color: #d32f2f;
      color: white;
      text-shadow: 0 0 5px rgba(255, 0, 0, 0.7);
    }

    .role-moderator {
      background-color: #7b1fa2;
      color: white;
      text-shadow: 0 0 5px rgba(180, 0, 255, 0.7);
    }

    .role-vip {
      background: linear-gradient(45deg, #ffc107, #ff9800);
      color: black;
      text-shadow: 0 0 5px rgba(255, 215, 0, 0.7);
    }

    .role-premium {
      background: linear-gradient(45deg, #4caf50, #8bc34a);
      color: white;
      text-shadow: 0 0 5px rgba(0, 255, 0, 0.7);
    }

    .role-helper {
      background-color: #0288d1;
      color: white;
      text-shadow: 0 0 5px rgba(0, 150, 255, 0.7);
    }

    .role-designer {
      background: linear-gradient(45deg, #e91e63, #9c27b0);
      color: white;
      text-shadow: 0 0 5px rgba(255, 0, 150, 0.7);
    }

    .role-developer {
      background-color: #607d8b;
      color: white;
      text-shadow: 0 0 5px rgba(100, 150, 200, 0.7);
    }

    .role-tester {
      background-color: #795548;
      color: white;
      text-shadow: 0 0 5px rgba(150, 100, 50, 0.7);
    }

    .role-writer {
      background: linear-gradient(45deg, #3f51b5, #2196f3);
      color: white;
      text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
    }

    .role-support {
      background: linear-gradient(45deg, #009688, #4caf50);
      color: white;
      text-shadow: 0 0 5px rgba(0, 255, 200, 0.7);
    }

    .role-guest {
      background-color: #9e9e9e;
      color: white;
      text-shadow: 0 0 5px rgba(200, 200, 200, 0.7);
    }

    .role-user {
      background-color: #1976d2;
      color: white;
      text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
    }

    /* Background image */
    .background-image {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) scale(0.7);
      width: 100vw;
      height: 100vh;
      z-index: -1;
      overflow: hidden;
      min-width: 800px;
      min-height: 800px;
    }

    .background-image img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: block;
      min-width: 800px;
      min-height: 800px;
    }

    @media (max-width: 768px) {
      .auth-panel {
        width: 90%;
        margin-top: 10vh;
        padding: 20px;
      }
      
      .auth-buttons {
        flex-direction: column;
        gap: 10px;
      }
      
      .auth-btn {
        width: 100%;
        padding: 12px 5px;
        font-size: 15px;
      }
      
      .input-group input {
        padding: 12px 14px;
      }
      
      .g-recaptcha {
        transform: scale(0.85);
        transform-origin: 0 0;
      }
    }

    @media (max-width: 480px) {
      .auth-btn {
        padding: 12px 5px;
        font-size: 14px;
        height: 40px;
      }
      
      .auth-title {
        font-size: 20px;
      }
      
      .input-group label {
        font-size: 14px;
      }
      
      .input-group input {
        font-size: 14px;
        padding: 10px 12px;
      }
      
      .g-recaptcha {
        transform: scale(0.75);
        transform-origin: 0 0;
      }
    }
  </style>
</head>
<body>



<div class="background-image">
  <img src="123333.png" alt="Фоновое изображение">
</div>

<div class="auth-panel">
  <?php if (isset($_SESSION['error'])): ?>
    <div class="message error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
  <?php endif; ?>
  
  <?php if (isset($_SESSION['success'])): ?>
    <div class="message success"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
  <?php endif; ?>

  <div id="login-form">
    <h2 class="auth-title">Вход в систему</h2>
    <form class="auth-form" method="POST">
      <input type="hidden" name="action" value="login">
      <div class="input-group">
        <label for="login-username">Логин</label>
        <input type="text" id="login-username" name="username" placeholder="Введите ваш логин" required>
      </div>
      <div class="input-group">
        <label for="login-password">Пароль</label>
        <input type="password" id="login-password" name="password" placeholder="Введите пароль" required>
      </div>
      <div class="auth-buttons">
        <button type="submit" class="auth-btn">Войти</button>
        <button type="button" class="auth-btn" onclick="showRegisterForm()">Регистрация</button>
      </div>
    </form>
  </div>

  <div id="register-form" class="register-form">
    <h2 class="auth-title">Регистрация</h2>
    <form class="auth-form" method="POST" id="registerForm">
      <input type="hidden" name="action" value="register">
      <div class="input-group">
        <label for="register-username">Логин</label>
        <input type="text" id="register-username" name="username" placeholder="Придумайте логин" required>
      </div>
      <div class="input-group">
        <label for="register-display-name">Имя для отображения</label>
        <input type="text" id="register-display-name" name="display_name" placeholder="Ваше имя или никнейм" required>
      </div>
      <div class="input-group">
        <label for="register-password">Пароль</label>
        <input type="password" id="register-password" name="password" placeholder="Придумайте пароль" required>
      </div>
      <div class="input-group">
        <label for="register-confirm-password">Подтвердите пароль</label>
        <input type="password" id="register-confirm-password" name="confirm_password" placeholder="Повторите пароль" required>
      </div>
      <div class="g-recaptcha" data-sitekey="6LfF8xorAAAAAHyn1h-woVjAdxXRXGsdUsPGerz2"></div>
      <div class="auth-buttons">
        <button type="submit" class="auth-btn" id="register-btn">Зарегистрироваться</button>
        <button type="button" class="auth-btn" onclick="showLoginForm()">Назад</button>
      </div>
    </form>
  </div>
</div>

<script>
  function showRegisterForm() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
    if (typeof grecaptcha !== 'undefined' && grecaptcha.reset) {
      grecaptcha.reset();
    }
  }

  function showLoginForm() {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
  }
  
  function checkFormsToShow() {
    <?php if (isset($_SESSION['show_register'])): ?>
      showRegisterForm();
      <?php unset($_SESSION['show_register']); ?>
    <?php elseif (isset($_SESSION['show_login'])): ?>
      showLoginForm();
      <?php unset($_SESSION['show_login']); ?>
    <?php endif; ?>
  }
  
  window.onload = checkFormsToShow;

  document.getElementById('registerForm')?.addEventListener('submit', function(e) {
    if (typeof grecaptcha === 'undefined') {
      e.preventDefault();
      alert('Ошибка загрузки reCAPTCHA. Пожалуйста, перезагрузите страницу');
      return false;
    }
    
    const recaptchaResponse = grecaptcha.getResponse();
    if (!recaptchaResponse) {
      e.preventDefault();
      alert('Пожалуйста, подтвердите, что вы не робот');
      return false;
    }
    return true;
  });
</script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</body>
</html>