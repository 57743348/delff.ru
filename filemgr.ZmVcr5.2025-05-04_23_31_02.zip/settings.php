<?php
session_start();

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Получаем текущие данные пользователя
$user = [];
try {
    $stmt = $pdo->prepare("SELECT username, display_name, avatar, bio, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
}

// Устанавливаем значения по умолчанию
$display_name = $user['display_name'] ?? '';
$bio = $user['bio'] ?? '';

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $display_name = trim($_POST['display_name'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $avatar = $user['avatar'] ?? '333.png';
    
    // Обработка загрузки аватарки
    if (!empty($_FILES['avatar']['name'])) {
        $uploadDir = 'uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Проверка типа файла
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($fileInfo, $_FILES['avatar']['tmp_name']);
        finfo_close($fileInfo);
        
        if (!in_array($mimeType, $allowedTypes)) {
            $_SESSION['error'] = 'Недопустимый тип файла. Разрешены только изображения (JPEG, PNG, GIF, WebP).';
            header("Location: settings.php");
            exit();
        }
        
        // Проверка размера файла (максимум 5MB)
        if ($_FILES['avatar']['size'] > 5 * 1024 * 1024) {
            $_SESSION['error'] = 'Файл слишком большой. Максимальный размер - 5MB.';
            header("Location: settings.php");
            exit();
        }
        
        // Генерация безопасного имени файла
        $fileExt = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        $validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($fileExt, $validExtensions)) {
            $_SESSION['error'] = 'Недопустимое расширение файла.';
            header("Location: settings.php");
            exit();
        }
        
        $fileName = 'avatar_' . $_SESSION['user_id'] . '_' . uniqid() . '.' . $fileExt;
        $targetPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $targetPath)) {
            // Автоматическая обрезка изображения в квадрат
            autoCropImage($targetPath, $targetPath);
            
            $avatar = $fileName;
            
            // Удаляем старый аватар, если это не дефолтный
            if (!empty($user['avatar']) && $user['avatar'] !== '333.png' && file_exists($uploadDir . $user['avatar'])) {
                unlink($uploadDir . $user['avatar']);
            }
        } else {
            $_SESSION['error'] = 'Ошибка при загрузке аватарки';
        }
    }
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET display_name = ?, avatar = ?, bio = ? WHERE user_id = ?");
        $stmt->execute([$display_name, $avatar, $bio, $_SESSION['user_id']]);
        
        $_SESSION['success'] = 'Профиль успешно обновлен';
        $_SESSION['display_name'] = $display_name;
        header("Location: profile.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Ошибка при обновлении профиля: ' . $e->getMessage();
    } 
}

/**
 * Автоматически обрезает изображение в квадрат
 */
function autoCropImage($src, $dest) {
    $type = exif_imagetype($src);
    
    switch ($type) {
        case IMAGETYPE_JPEG:
            $sourceImage = imagecreatefromjpeg($src);
            break;
        case IMAGETYPE_PNG:
            $sourceImage = imagecreatefrompng($src);
            break;
        case IMAGETYPE_GIF:
            $sourceImage = imagecreatefromgif($src);
            break;
        case IMAGETYPE_WEBP:
            $sourceImage = imagecreatefromwebp($src);
            break;
        default:
            return false;
    }
    
    $width = imagesx($sourceImage);
    $height = imagesy($sourceImage);
    
    // Определяем размер квадрата и координаты для обрезки
    $size = min($width, $height);
    $x = ($width - $size) / 2;
    $y = ($height - $size) / 2;
    
    // Создаем квадратное изображение
    $squareImage = imagecrop($sourceImage, ['x' => $x, 'y' => $y, 'width' => $size, 'height' => $size]);
    
    if ($squareImage === false) {
        return false;
    }
    
    // Создаем миниатюру стандартного размера (500x500)
    $thumb = imagecreatetruecolor(500, 500);
    
    // Сохраняем прозрачность для PNG/GIF
    if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
        imagecolortransparent($thumb, imagecolorallocatealpha($thumb, 0, 0, 0, 127));
        imagealphablending($thumb, false);
        imagesavealpha($thumb, true);
    }
    
    // Ресайз изображения
    imagecopyresampled($thumb, $squareImage, 0, 0, 0, 0, 500, 500, $size, $size);
    
    // Сохраняем результат
    switch ($type) {
        case IMAGETYPE_JPEG:
            imagejpeg($thumb, $dest, 90);
            break;
        case IMAGETYPE_PNG:
            imagepng($thumb, $dest, 9);
            break;
        case IMAGETYPE_GIF:
            imagegif($thumb, $dest);
            break;
        case IMAGETYPE_WEBP:
            imagewebp($thumb, $dest, 90);
            break;
    }
    
    imagedestroy($sourceImage);
    imagedestroy($squareImage);
    imagedestroy($thumb);
    
    return true;
}

// Функция для получения класса роли
function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    
    return isset($roles[$role]) ? $roles[$role] : 'user';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Настройки - Interpol organizations</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Oswald', sans-serif;
        }

        body {
            background-color: #1a1a1a;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            flex: 1;
        }

        /* Header */
        .header {
            background-color: #272727;
            height: 45px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            border-bottom: 1px solid #3d3d3d;
            width: 100%;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-img {
            height: 30px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: 400;
            color: #fff;
        }

        .nav {
            display: flex;
            margin-left: 30px;
        }

        .nav-item {
            color: #fff;
            text-decoration: none;
            padding: 0 15px;
            font-size: 16px;
            transition: color 0.3s;
            height: 45px;
            display: flex;
            align-items: center;
        }

        .nav-item:hover {
            color: #ccc;
            background-color: #3d3d3d;
        }

        .user-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #fff;
            position: relative;
        }

        .online-indicator {
            width: 8px;
            height: 8px;
            background-color: #4CAF50;
            border-radius: 50%;
            position: absolute;
            bottom: 0;
            right: 0;
            border: 1px solid #272727;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #272727;
            min-width: 150px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }

        .dropdown-menu a {
            color: #fff;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-menu a:hover {
            background-color: #3d3d3d;
        }

        .user-role {
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 3px;
        }

        /* Main Content */
        .main-content {
            display: flex;
            min-height: calc(100vh - 45px);
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }
  /* Sidebar */
    .sidebar {
        width: 280px;
        background-color: rgba(39, 39, 39, 0.7);
        padding: 20px;
        border-right: 1px solid #3d3d3d;
    }

    .sidebar-title {
        color: #ccc;
        font-size: 18px;
        margin-bottom: 15px;
        padding-bottom: 5px;
        border-bottom: 1px solid #3d3d3d;
    }

    .sidebar-item {
        color: #fff;
        display: block;
        padding: 8px 10px;
        margin-bottom: 5px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.3s;
    }

    .sidebar-item:hover {
        background-color: #3d3d3d;
    }

    /* Стили для раскрывающихся кнопок */
    .dropdown-btn {
        background-color: rgba(39, 39, 39, 0);
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
        width: 100%;
        border: none;
        text-align: left;
        cursor: pointer;
        border-radius: 4px;
        margin-bottom: 5px;
        transition: all 0.3s;
    }

    .dropdown-btn:hover {
        background-color: #3d3d3d;
    }

    .dropdown-btn.active {
        background-color: #3d3d3d;
        border-radius: 4px 4px 0 0;
        margin-bottom: 0;
    }

    .dropdown-btn::after {
        content: "▼";
        font-size: 12px;
    }

    .dropdown-btn.active::after {
        content: "▲";
    }

    .dropdown-container {
        display: none;
        background-color: #1e1e1e;
        padding: 0;
        border-radius: 0 0 4px 4px;
        margin-bottom: 5px;
        overflow: hidden;
    }

    .dropdown-container a {
        color: #fff;
        padding: 8px 20px;
        text-decoration: none;
        display: block;
        transition: all 0.3s;
    }

    .dropdown-container a:hover {
        background-color: #333;
    }
    
    .create-post-btn {
        background-color: #fff;
        color: #000;
        display: block;
        width: 100%;
        padding: 10px;
        text-align: center;
        border-radius: 6px;
        font-size: 16px;
        margin-bottom: 20px;
        cursor: pointer;
        transition: background-color 0.3s;
        border: none;
    }

    .create-post-btn:hover {
        background-color: #e6e6e6;
    }

    /* Content Area */
    .content {
        flex: 1;
        padding: 20px;
        max-width: 900px;
    }

        /* Settings Container */
        .settings-container {
            background-color: rgba(39, 39, 39, 0.7);
            border-radius: 7px;
            padding: 30px;
            margin-bottom: 20px;
        }

        .settings-title {
            font-size: 24px;
            margin-bottom: 30px;
            text-align: center;
            color: #fff;
        }

        .settings-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-size: 16px;
            color: #ddd;
        }

        .form-group input[type="text"],
        .form-group textarea {
            padding: 10px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid #555;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            transition: all 0.3s;
        }

        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #777;
            background: rgba(255, 255, 255, 0.15);
        }

        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }

        .avatar-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #555;
            margin-top: 10px;
        }

        /* Стилизация кнопки загрузки файла */
        .custom-file-upload {
            display: inline-block;
            padding: 10px 20px;
            background: #2d2d2d;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
            text-align: center;
            width: fit-content;
            margin-top: 10px;
        }

        .custom-file-upload:hover {
            background: #3d3d3d;
        }

        /* Скрываем стандартный input file */
        input[type="file"] {
            display: none;
        }

        .save-btn {
            padding: 12px 20px;
            background: #2d2d2d;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
            margin-top: 20px;
            width: 100%;
        }

        .save-btn:hover {
            background: #3d3d3d;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .error {
            background-color: rgba(255, 0, 0, 0.2);
            border: 1px solid rgba(255, 0, 0, 0.5);
        }

        .success {
            background-color: rgba(0, 255, 0, 0.2);
            border: 1px solid rgba(0, 255, 0, 0.5);
        }

        /* Background image */
        .background-image {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.7);
            width: 100vw;
            height: 100vh;
            z-index: -1;
            overflow: hidden;
            min-width: 800px;
            min-height: 800px;
        }

        .background-image img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            display: block;
            min-width: 800px;
            min-height: 800px;
        }

        /* Right section */
        .right-section {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
        }

        .user-role {
            display: inline-block;
            font-size: 0.7rem;
            padding: 2px 5px;
            border-radius: 3px;
            margin-right: 5px;
            text-transform: uppercase;
            font-weight: bold;
        }

        .role-admin {
            background-color: #d32f2f;
            color: white;
            text-shadow: 0 0 5px rgba(255, 0, 0, 0.7);
        }

        .role-moderator {
            background-color: #7b1fa2;
            color: white;
            text-shadow: 0 0 5px rgba(180, 0, 255, 0.7);
        }

        .role-vip {
            background: linear-gradient(45deg, #ffc107, #ff9800);
            color: black;
            text-shadow: 0 0 5px rgba(255, 215, 0, 0.7);
        }

        .role-premium {
            background: linear-gradient(45deg, #4caf50, #8bc34a);
            color: white;
            text-shadow: 0 0 5px rgba(0, 255, 0, 0.7);
        }

        .role-helper {
            background-color: #0288d1;
            color: white;
            text-shadow: 0 0 5px rgba(0, 150, 255, 0.7);
        }

        .role-designer {
            background: linear-gradient(45deg, #e91e63, #9c27b0);
            color: white;
            text-shadow: 0 0 5px rgba(255, 0, 150, 0.7);
        }

        .role-developer {
            background-color: #607d8b;
            color: white;
            text-shadow: 0 0 5px rgba(100, 150, 200, 0.7);
        }

        .role-tester {
            background-color: #795548;
            color: white;
            text-shadow: 0 0 5px rgba(150, 100, 50, 0.7);
        }

        .role-writer {
            background: linear-gradient(45deg, #3f51b5, #2196f3);
            color: white;
            text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
        }

        .role-support {
            background: linear-gradient(45deg, #009688, #4caf50);
            color: white;
            text-shadow: 0 0 5px rgba(0, 255, 200, 0.7);
        }

        .role-guest {
            background-color: #9e9e9e;
            color: white;
            text-shadow: 0 0 5px rgba(200, 200, 200, 0.7);
        }

        .role-user {
            background-color: #1976d2;
            color: white;
            text-shadow: 0 0 5px rgba(0, 100, 255, 0.7);
        }

        .right-image {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #555;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .right-image:hover {
            transform: scale(1.1);
        }

        .dropdown-menu1 {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #333;
            border-radius: 5px;
            padding: 10px 0;
            min-width: 150px;
            z-index: 100;
        }

        .dropdown-menu1 a {
            display: block;
            padding: 8px 15px;
            font-size: 14px;
            color: white;
            text-decoration: none;
            white-space: nowrap;
        }

        .dropdown-menu1 a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .right-section:hover .dropdown-menu1 {
            display: block;
        }

        /* Информация о загруженном файле */
        .file-info {
            margin-top: 10px;
            font-size: 14px;
            color: #aaa;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #3d3d3d;
            }
            
            .settings-container {
                padding: 20px;
            }
            
            .avatar-preview {
                width: 80px;
                height: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="dsdsd.png" alt="Interpol Logo" class="logo-img">
            <div class="logo-text">Interpol organizations</div>
        </div>
        <nav class="nav">
    
            <a href="onas.php" class="nav-item">О нас</a>
        </nav>
        
        <div class="right-section">
            <a href="profile.php" style="color: white; text-decoration: none;">
                <span class="user-role role-<?= getRoleClass($user['role']) ?>">
                    <?= strtoupper($user['role']) ?>
                </span>
                <?= htmlspecialchars($user['display_name'] ?? 'Пользователь') ?>
            </a>
            <div style="position: relative;">
                <img src="/uploads/<?= htmlspecialchars($user['avatar'] ?? '333.png') ?>" alt="Аватар" class="right-image">
                <span class="online-indicator"></span>
            </div>
            
            <!-- Dropdown menu -->
            <div class="dropdown-menu1">
                <a href="profile.php">Профиль</a>
                <a href="settings.php">Настройки</a>
                <a href="logout.php">Выйти</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="main-content">
            <!-- Sidebar -->
           <aside class="sidebar">
                                  <button class="create-post-btn" onclick="window.location.href='addpost.php'">Создать пост</button>
                                
               
                <div class="sidebar-section">
                    <div class="sidebar-title">Категории</div>
                </div>
                 <a href="main.php" class="sidebar-item glow-hover">Главная</a>
                <!-- Кнопка Cheat с выпадающим списком -->
                <button class="dropdown-btn">Cheat</button>
                <div class="dropdown-container" style="display: none;">
                    <a href="cs2.php">Counter-Strike 2</a>
                    <a href="roblox.php">Roblox</a>
                    <a href="dota2.php">Dota 2</a>
                    <a href="other.php">Остальное</a>
                    
                </div>
                
                <div class="sidebar-section">
                    <div class="sidebar-title">Обсуждение</div>
                    <a href="offers.php" class="sidebar-item">Предложения</a>
                    <a href="addrole.php" class="sidebar-item">Заявки на роль</a>
                </div>
            </aside>

            <!-- Content Area -->
            <main class="content">
                <div class="settings-container">
                    <h1 class="settings-title">Настройки профиля</h1>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="message error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="message success"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
                    <?php endif; ?>

                    <form class="settings-form" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="display_name">Отображаемое имя</label>
                            <input type="text" id="display_name" name="display_name" value="<?= htmlspecialchars($display_name) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="avatar">Аватар</label>
                            
                            <label for="avatar" class="custom-file-upload">
                                Выбрать изображение
                            </label>
                            <input type="file" id="avatar" name="avatar" accept="image/*">
                            <div class="file-info" id="file-info">Файл не выбран</div>
                            
                            <?php if (!empty($user['avatar'])): ?>
                                <img src="/uploads/<?= htmlspecialchars($user['avatar']) ?>" alt="Текущий аватар" class="avatar-preview" id="current-avatar">
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="bio">О себе</label>
                            <textarea id="bio" name="bio"><?= htmlspecialchars($bio) ?></textarea>
                        </div>
                        
                        <button type="submit" class="save-btn">Сохранить изменения</button>
                    </form>
                </div>
            </main>
        </div>
    </div>

    <!-- Background image -->
    <div class="background-image">
        <img src="123333.png" alt="Фоновое изображение">
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const avatarInput = document.getElementById('avatar');
        const fileInfo = document.getElementById('file-info');
        const currentAvatar = document.getElementById('current-avatar');
        
        // Отображение имени выбранного файла
        avatarInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) {
                fileInfo.textContent = 'Файл не выбран';
                return;
            }
            
            if (!file.type.match('image.*')) {
                fileInfo.textContent = 'Пожалуйста, выберите изображение';
                return;
            }
            
            // Показываем имя и размер файла
            const fileSize = (file.size / 1024).toFixed(2) + ' KB';
            fileInfo.textContent = `${file.name} (${fileSize})`;
            
            // Показываем предпросмотр выбранного изображения
            const reader = new FileReader();
            reader.onload = function(event) {
                if (currentAvatar) {
                    currentAvatar.src = event.target.result;
                } else {
                    const preview = document.createElement('img');
                    preview.className = 'avatar-preview';
                    preview.id = 'current-avatar';
                    preview.src = event.target.result;
                    avatarInput.parentNode.appendChild(preview);
                }
            };
            reader.readAsDataURL(file);
        });
        
        // Обновление статуса онлайн
        function updateOnlineStatus() {
            fetch('update_activity.php')
                .then(response => response.json())
                .then(data => {
                    const onlineIndicator = document.querySelector('.online-indicator');
                    if (data.is_online) {
                        onlineIndicator.style.display = 'block';
                    } else {
                        onlineIndicator.style.display = 'none';
                    }
                })
                .catch(error => console.error('Ошибка:', error));
        }

        // Обновляем статус каждые 30 секунд
        setInterval(updateOnlineStatus, 30000);
        updateOnlineStatus();
    });
    
        // Скрипт для раскрывающихся кнопок в боковой панели
    document.querySelectorAll(".dropdown-btn").forEach(btn => {
        btn.addEventListener("click", function(event) {
            event.stopPropagation();
            this.classList.toggle("active");
            const dropdownContent = this.nextElementSibling;
            dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
        });
    });
    </script>
</body>
</html>