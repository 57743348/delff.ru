<?php
session_start();
require 'db_connect.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || !isset($_POST['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Недостаточно прав']);
    exit();
}

try {
    // Check if current user is admin
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if ($user['role'] !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Недостаточно прав']);
        exit();
    }
    
    // Prevent self-deletion
    if ($_POST['user_id'] == $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'error' => 'Нельзя удалить свой аккаунт']);
        exit();
    }
    
    // Delete user
    $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
    $stmt->execute([$_POST['user_id']]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Ошибка базы данных']);
}
?>