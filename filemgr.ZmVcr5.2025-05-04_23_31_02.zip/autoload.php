<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db_connect.php';

// Обновление активности пользователя
$current_time = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("UPDATE users SET last_activity = ? WHERE user_id = ?");
$stmt->execute([$current_time, $_SESSION['user_id']]);

// Получение количества онлайн пользователей
$online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
$online_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE last_activity > ?");
    $stmt->execute([$online_threshold]);
    $result = $stmt->fetch();
    $online_count = $result['count'];
} catch (PDOException $e) {
    // Игнорируем ошибку
}

// Получение данных пользователя
$user = [];
try {
    $stmt = $pdo->prepare("SELECT username, avatar, bio, display_name, last_activity, role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении данных пользователя';
}

function isUserOnline($last_activity) {
    $online_threshold = date('Y-m-d H:i:s', strtotime('-5 seconds'));
    return $last_activity > $online_threshold;
}

function getRoleClass($role) {
    $role = strtolower($role);
    $roles = [
        'admin' => 'admin',
        'moderator' => 'moderator',
        'vip' => 'vip',
        'premium' => 'premium',
        'helper' => 'helper',
        'designer' => 'designer',
        'developer' => 'developer',
        'tester' => 'tester',
        'writer' => 'writer',
        'support' => 'support',
        'guest' => 'guest'
    ];
    return $roles[$role] ?? 'user';
}

// Обработка отправки заявки на роль
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['role_request'])) {
    $requested_role = trim($_POST['requested_role']);
    $request_text = trim($_POST['request_text']);
    
    if (!empty($requested_role) && !empty($request_text)) {
        try {
            // Проверяем, есть ли уже активная заявка от этого пользователя
            $stmt = $pdo->prepare("SELECT * FROM role_requests WHERE user_id = ? AND status = 'pending'");
            $stmt->execute([$_SESSION['user_id']]);
            $existing_request = $stmt->fetch();
            
            if ($existing_request) {
                $_SESSION['error'] = 'У вас уже есть активная заявка на роль';
            } else {
                $stmt = $pdo->prepare("INSERT INTO role_requests (user_id, requested_role, request_text, created_at) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$_SESSION['user_id'], $requested_role, $request_text]);
                $_SESSION['success'] = 'Ваша заявка на роль отправлена!';
                header("Location: roles.php");
                exit();
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Ошибка при отправке заявки';
            error_log("Error adding role request: " . $e->getMessage());
        }
    } else {
        $_SESSION['error'] = 'Заполните все поля';
    }
}

// Обработка действий администратора
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) {
    if ($user['role'] === 'admin') {
        $request_id = intval($_POST['request_id']);
        $action = $_POST['action'];
        
        try {
            if ($action === 'approve') {
                // Получаем данные заявки
                $stmt = $pdo->prepare("SELECT * FROM role_requests WHERE request_id = ?");
                $stmt->execute([$request_id]);
                $request = $stmt->fetch();
                
                if ($request) {
                    // Обновляем роль пользователя
                    $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE user_id = ?");
                    $stmt->execute([$request['requested_role'], $request['user_id']]);
                    
                    // Обновляем статус заявки
                    $stmt = $pdo->prepare("UPDATE role_requests SET status = 'approved', processed_at = NOW() WHERE request_id = ?");
                    $stmt->execute([$request_id]);
                    
                    $_SESSION['success'] = 'Роль успешно назначена!';
                }
            } elseif ($action === 'reject') {
                $stmt = $pdo->prepare("UPDATE role_requests SET status = 'rejected', processed_at = NOW() WHERE request_id = ?");
                $stmt->execute([$request_id]);
                $_SESSION['success'] = 'Заявка отклонена';
            } elseif ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM role_requests WHERE request_id = ?");
                $stmt->execute([$request_id]);
                $_SESSION['success'] = 'Заявка удалена';
            }
            
            header("Location: roles.php");
            exit();
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Ошибка при обработке заявки';
            error_log("Error processing role request: " . $e->getMessage());
        }
    }
}

// Получаем все заявки на роли
$role_requests = [];
try {
    $stmt = $pdo->prepare("
        SELECT r.request_id, r.requested_role, r.request_text, r.created_at, r.status, r.processed_at,
               u.user_id, u.username, u.avatar, u.display_name, u.role, u.last_activity
        FROM role_requests r
        JOIN users u ON r.user_id = u.user_id
        ORDER BY r.created_at DESC
    ");
    $stmt->execute();
    $role_requests = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = 'Ошибка при получении заявок на роли';
}

// Доступные роли для запроса
$available_roles = [
    'moderator' => 'Модератор',
    'helper' => 'Помощник',
    'designer' => 'Дизайнер',
    'developer' => 'Разработчик',
    'writer' => 'Писатель',
    'support' => 'Поддержка'
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Заявки на роли | Interpol Organizations</title>
  <link rel="icon" href="/uploads/favicon.ico">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Oswald', sans-serif;
    }

    body {
        background-color: #1a1a1a;
        color: #ffffff;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .container {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        flex: 1;
    }

    /* Header */
    .header {
        background-color: #272727;
        height: 45px;
        display: flex;
        align-items: center;
        padding: 0 20px;
        border-bottom: 1px solid #3d3d3d;
        width: 100%;
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .logo-img {
        height: 30px;
    }

    .logo-text {
        font-size: 20px;
        font-weight: 400;
        color: #fff;
    }

    .nav {
        display: flex;
        margin-left: 30px;
    }

    .nav-item {
        color: #fff;
        text-decoration: none;
        padding: 0 15px;
        font-size: 16px;
        transition: color 0.3s;
        height: 45px;
        display: flex;
        align-items: center;
    }

    .nav-item:hover {
        color: #ccc;
        background-color: #3d3d3d;
    }

    .right-section {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 10px;
        position: relative;
    }

    .user-role {
        display: inline-block;
        font-size: 0.7rem;
        padding: 2px 5px;
        border-radius: 3px;
        margin-right: 5px;
        text-transform: uppercase;
        font-weight: bold;
    }

    /* Стили для ролей */
    .role-admin {
        background-color: #d32f2f;
        color: white;
    }

    .role-moderator {
        background-color: #7b1fa2;
        color: white;
    }

    .role-vip {
        background-color: #ff9800;
        color: white;
    }

    .role-premium {
        background-color: #2196F3;
        color: white;
    }

    .role-helper {
        background-color: #4CAF50;
        color: white;
    }

    .role-designer {
        background-color: #9C27B0;
        color: white;
    }

    .role-developer {
        background-color: #607D8B;
        color: white;
    }

    .role-tester {
        background-color: #795548;
        color: white;
    }

    .role-writer {
        background-color: #3F51B5;
        color: white;
    }

    .role-support {
        background-color: #009688;
        color: white;
    }

    .role-guest {
        background-color: #9E9E9E;
        color: white;
    }

    .role-user {
        background-color: #1976d2;
        color: white;
    }

    .right-image {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid #555;
        cursor: pointer;
        transition: transform 0.3s;
    }

    .right-image:hover {
        transform: scale(1.1);
    }

    .dropdown-menu1 {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        background: rgba(0, 0, 0, 0.9);
        border: 1px solid #333;
        border-radius: 5px;
        padding: 10px 0;
        min-width: 150px;
        z-index: 100;
    }

    .dropdown-menu1 a {
        display: block;
        padding: 8px 15px;
        font-size: 14px;
        color: white;
        text-decoration: none;
        white-space: nowrap;
    }

    .dropdown-menu1 a:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    .right-section:hover .dropdown-menu1 {
        display: block;
    }

    /* Online counter */
    .online-counter {
        position: fixed;
        top: 60px;
        right: 20px;
        background-color: #272727;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 14px;
        z-index: 100;
    }

    /* Main Content */
    .main-content {
        display: flex;
        min-height: calc(100vh - 45px);
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
    }

    /* Sidebar */
    .sidebar {
        width: 280px;
        background-color: rgba(39, 39, 39, 0.7);
        padding: 20px;
        border-right: 1px solid #3d3d3d;
    }

    .sidebar-title {
        color: #ccc;
        font-size: 18px;
        margin-bottom: 15px;
        padding-bottom: 5px;
        border-bottom: 1px solid #3d3d3d;
    }

    .sidebar-item {
        color: #fff;
        display: block;
        padding: 8px 10px;
        margin-bottom: 5px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.3s;
    }

    .sidebar-item:hover {
        background-color: #3d3d3d;
    }

    .sidebar-item.active {
        background-color: #3d3d3d;
        font-weight: 500;
    }

    /* Content Area */
    .content {
        flex: 1;
        padding: 20px;
        max-width: 900px;
    }

    /* Requests section */
    .requests-section {
        background-color: #272727;
        border-radius: 7px;
        padding: 20px;
        margin-bottom: 20px;
    }

    .requests-title {
        font-size: 20px;
        margin-bottom: 15px;
        color: #fff;
    }

    .request-form {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-label {
        display: block;
        margin-bottom: 5px;
        color: #ccc;
    }

    .form-select {
        width: 100%;
        padding: 8px 10px;
        border-radius: 4px;
        border: 1px solid #3d3d3d;
        background-color: #2d2d2d;
        color: #fff;
    }

    .request-textarea {
        width: 100%;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #3d3d3d;
        background-color: #2d2d2d;
        color: #fff;
        min-height: 100px;
        margin-bottom: 10px;
        resize: vertical;
    }

    .request-submit {
        background-color: #1976d2;
        color: #fff;
        padding: 8px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .request-submit:hover {
        background-color: #1565c0;
    }

    .request-list {
        margin-top: 20px;
    }

    .request-item {
        background-color: #2d2d2d;
        border-radius: 4px;
        padding: 15px;
        margin-bottom: 15px;
        border-left: 4px solid #3d3d3d;
    }

    .request-item.pending {
        border-left-color: #ffc107;
    }

    .request-item.approved {
        border-left-color: #4CAF50;
    }

    .request-item.rejected {
        border-left-color: #f44336;
    }

    .request-header {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }

    .request-avatar {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-right: 10px;
        position: relative;
    }

    .request-author {
        font-weight: 500;
        margin-right: 10px;
    }

    .request-date {
        color: #999;
        font-size: 12px;
        margin-left: auto;
    }

    .request-status {
        font-size: 12px;
        padding: 2px 5px;
        border-radius: 3px;
        margin-left: 10px;
    }

    .status-pending {
        background-color: #ffc107;
        color: #000;
    }

    .status-approved {
        background-color: #4CAF50;
        color: #fff;
    }

    .status-rejected {
        background-color: #f44336;
        color: #fff;
    }

    .request-content {
        line-height: 1.5;
        color: #eee;
        margin-bottom: 10px;
        word-wrap: break-word;
        white-space: pre-line;
    }

    .request-role {
        font-weight: bold;
        color: #4CAF50;
        margin-bottom: 5px;
    }

    .request-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }

    .request-action {
        color: #999;
        font-size: 12px;
        cursor: pointer;
        transition: color 0.3s;
    }

    .request-action:hover {
        color: #fff;
    }

    /* Messages */
    .message {
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
    }

    .error {
        background-color: #d32f2f;
        color: #fff;
    }

    .success {
        background-color: #388e3c;
        color: #fff;
    }

    /* Background image */
    .background-image {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.7);
        width: 100vw;
        height: 100vh;
        z-index: -1;
        overflow: hidden;
        min-width: 800px;
        min-height: 800px;
    }
    
    .glow-hover {
        color: #fff;
        transition: text-shadow 0.3s ease;
        text-shadow: 0 0 8px white, 0 0 16px white;
    }

    .background-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
        min-width: 800px;
        min-height: 800px;
    }

    .online-indicator {
        width: 8px;
        height: 8px;
        background-color: #4CAF50;
        border-radius: 50%;
        position: absolute;
        bottom: 0;
        right: 0;
        border: 1px solid #272727;
    }

    .role-badge {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 12px;
        font-weight: bold;
        margin-left: 5px;
    }
  </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="dsdsd.png" alt="Interpol Logo" class="logo-img">
            <div class="logo-text">Interpol organizations</div>
        </div>
        <nav class="nav">
            <a href="onas.php" class="nav-item">О нас</a>
            <a href="roles.php" class="nav-item active">Заявки на роли</a>
        </nav>
        
        <!-- Online counter -->
        <div class="online-counter" id="onlineCounter">
            Онлайн: <?= $online_count ?>
        </div>
        
        <div class="right-section">
            <a href="profile.php" style="color: white; text-decoration: none;">
                <span class="user-role role-<?= getRoleClass($user['role']) ?>">
                    <?= strtoupper($user['role']) ?>
                </span>
                <?= htmlspecialchars($user['display_name'] ?? 'Пользователь') ?>
            </a>
            <div style="position: relative;" data-user-id="<?= $_SESSION['user_id'] ?>">
                <img src="/uploads/<?= htmlspecialchars($user['avatar'] ?? '333.png') ?>" alt="Аватар" class="right-image">
                <span class="online-indicator" style="display: <?= isUserOnline($user['last_activity']) ? 'block' : 'none' ?>;"></span>
            </div>
            
            <!-- Dropdown menu -->
            <div class="dropdown-menu1">
                <a href="profile.php">Профиль</a>
                <a href="settings.php">Настройки</a>
                <a href="logout.php">Выйти</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
                <div class="sidebar-section">
                    <div class="sidebar-title">Навигация</div>
                    <a href="main.php" class="sidebar-item">Главная</a>
                    <a href="roles.php" class="glow-hover sidebar-item active">Заявки на роли</a>
                    <?php if ($user['role'] === 'admin'): ?>
                        <a href="admin.php" class="sidebar-item">Панель администратора</a>
                    <?php endif; ?>
                </div>
            </aside>

            <!-- Content Area -->
            <main class="content">
                <!-- Requests section -->
                <div class="requests-section">
                    <h2 class="requests-title">Заявки на получение ролей</h2>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="message error"><?= $_SESSION['error'] ?></div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="message success"><?= $_SESSION['success'] ?></div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <!-- Request form -->
                    <form class="request-form" method="POST">
                        <input type="hidden" name="role_request" value="1">
                        
                        <div class="form-group">
                            <label class="form-label" for="requested_role">Желаемая роль:</label>
                            <select name="requested_role" id="requested_role" class="form-select" required>
                                <option value="">-- Выберите роль --</option>
                                <?php foreach ($available_roles as $value => $label): ?>
                                    <option value="<?= $value ?>"><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="request_text">Почему вы достойны этой роли?</label>
                            <textarea name="request_text" id="request_text" class="request-textarea" placeholder="Опишите, почему вы должны получить эту роль..." required></textarea>
                        </div>
                        
                        <button type="submit" class="request-submit">Отправить заявку</button>
                    </form>
                    
                    <!-- Requests list -->
                    <div class="request-list">
                        <?php if (empty($role_requests)): ?>
                            <div class="request-item">Пока нет заявок на роли.</div>
                        <?php else: ?>
                            <?php foreach ($role_requests as $request): ?>
                                <div class="request-item <?= $request['status'] ?>">
                                    <div class="request-header">
                                        <div class="request-avatar" data-user-id="<?= $request['user_id'] ?>">
                                            <img src="/uploads/<?= htmlspecialchars($request['avatar'] ?? '333.png') ?>" alt="Аватар" style="width:100%;height:100%;object-fit:cover;">
                                            <span class="online-indicator" style="display: <?= isUserOnline($request['last_activity']) ? 'block' : 'none' ?>;"></span>
                                        </div>
                                        <div class="request-author">
                                            <?= htmlspecialchars($request['display_name']) ?>
                                        </div>
                                        <span class="request-status status-<?= $request['status'] ?>">
                                            <?= $request['status'] === 'pending' ? 'На рассмотрении' : 
                                               ($request['status'] === 'approved' ? 'Принято' : 'Отклонено') ?>
                                        </span>
                                        <div class="request-date">
                                            <?= date('d.m.Y H:i', strtotime($request['created_at'])) ?>
                                        </div>
                                    </div>
                                    
                                    <div class="request-role">
                                        Запрашиваемая роль: 
                                        <span class="role-badge role-<?= getRoleClass($request['requested_role']) ?>">
                                            <?= strtoupper($request['requested_role']) ?>
                                        </span>
                                    </div>
                                    
                                    <div class="request-content">
                                        <?= nl2br(htmlspecialchars($request['request_text'])) ?>
                                    </div>
                                    
                                    <?php if ($user['role'] === 'admin' || $request['user_id'] == $_SESSION['user_id']): ?>
                                        <div class="request-actions">
                                            <?php if ($user['role'] === 'admin' && $request['status'] === 'pending'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                                                    <input type="hidden" name="action" value="approve">
                                                    <button type="submit" class="request-action">Принять</button>
                                                </form>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                                                    <input type="hidden" name="action" value="reject">
                                                    <button type="submit" class="request-action">Отклонить</button>
                                                </form>
                                            <?php endif; ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" class="request-action" onclick="return confirm('Вы уверены, что хотите удалить эту заявку?')">Удалить</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($request['status'] !== 'pending' && $request['processed_at']): ?>
                                        <div class="request-date" style="margin-top: 5px; font-size: 12px;">
                                            <?= $request['status'] === 'approved' ? 'Принято' : 'Отклонено' ?>: 
                                            <?= date('d.m.Y H:i', strtotime($request['processed_at'])) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Background image -->
    <div class="background-image">
        <img src="123333.png" alt="Фоновое изображение">
    </div>

    <script>
    // Функция для обновления онлайн статуса
    function updateOnlineStatus() {
        fetch('update_activity.php')
            .then(response => response.json())
            .then(data => {
                const onlineCounter = document.getElementById('onlineCounter');
                if (onlineCounter) {
                    onlineCounter.textContent = `Онлайн: ${data.online_count}`;
                }
                
                document.querySelectorAll('.online-indicator').forEach(indicator => {
                    const parentDiv = indicator.closest('[data-user-id]');
                    if (parentDiv) {
                        const userId = parseInt(parentDiv.getAttribute('data-user-id'));
                        if (data.online_users.includes(userId)) {
                            indicator.style.display = 'block';
                        } else {
                            indicator.style.display = 'none';
                        }
                    }
                });
            })
            .catch(error => console.error('Ошибка при обновлении статуса:', error));
    }

    // Initialize
    updateOnlineStatus();
    
    // Обновляем онлайн статус при возвращении на страницу
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            updateOnlineStatus();
        }
    });

    // Обновляем онлайн статус каждые 30 секунд
    setInterval(updateOnlineStatus, 30000);

    // Обработка отправки формы заявки
    document.querySelector('.request-form')?.addEventListener('submit', function(e) {
        const select = this.querySelector('select');
        const textarea = this.querySelector('textarea');
        
        if (select.value.trim().length === 0 || textarea.value.trim().length === 0) {
            e.preventDefault();
            alert('Заполните все поля');
        }
    });
    </script>
</body>
</html>