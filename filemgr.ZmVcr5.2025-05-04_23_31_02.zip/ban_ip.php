<?php
session_start();

// Проверка авторизации и прав администратора
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Необходима авторизация']);
    exit();
}

require 'db_connect.php';

// Проверяем, является ли пользователь администратором
try {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user || $user['role'] !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Недостаточно прав']);
        exit();
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Ошибка базы данных']);
    exit();
}

// Проверяем параметры запроса
if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Не указан ID пользователя']);
    exit();
}

$user_id = $_POST['user_id'];
$reason = isset($_POST['reason']) ? $_POST['reason'] : '';

try {
    // Получаем IP-адрес пользователя
    $stmt = $pdo->prepare("SELECT last_ip FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data || empty($user_data['last_ip'])) {
        echo json_encode(['success' => false, 'error' => 'IP-адрес пользователя не найден']);
        exit();
    }
    
    $ip_address = $user_data['last_ip'];
    
    // Проверяем, не заблокирован ли уже этот IP
    $stmt = $pdo->prepare("SELECT id FROM banned_ips WHERE ip_address = ?");
    $stmt->execute([$ip_address]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Этот IP-адрес уже заблокирован']);
        exit();
    }
    
    // Добавляем IP в таблицу заблокированных
    $stmt = $pdo->prepare("INSERT INTO banned_ips (ip_address, banned_by, reason, banned_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$ip_address, $_SESSION['user_id'], $reason]);
    
    // Логирование действия
    $stmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, target_id, details, action_time) VALUES (?, 'ban_ip', ?, ?, NOW())");
    $stmt->execute([$_SESSION['user_id'], $user_id, "IP: {$ip_address}, Причина: {$reason}"]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Ошибка базы данных: ' . $e->getMessage()]);
}